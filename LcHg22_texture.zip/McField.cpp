// Implementation of the CMcField class.
//
////////////////////////////////////////////////////////////////////////////////

#pragma warning( disable : 4996)

#include <windows.h>
#include <stdio.h>
#include <d3d9.h>
#include <d3dx9.h>

#include "dxutil.h"

#include "McField.h"


CMcField::CMcField()
{
	m_pVtx	= NULL;
	m_pFce	= NULL;

	m_TileN	= 0;
	m_TileW	= 0;

	m_nVtx	= 0;
	m_nFce	= 0;
	m_pTx   = NULL;
}

CMcField::~CMcField()
{
	Destroy();
}


INT CMcField::Create(LPDIRECT3DDEVICE9 pDev, char* sRaw, char* sTexture)
{
	m_pDev	= pDev;

	int x;
	int z;
	int n;

	m_TileN = 128;
	m_TileW = 4.f;
	m_fHscl = .8f;

	m_nVtx = (m_TileN+1) * (m_TileN+1);
	m_nFce = 2* m_TileN * m_TileN;


	m_pVtx = new VtxDUV1[m_nVtx];
	m_pFce = new VtxIdx[m_nFce];

	
//	1-----3
//	.\    |
//	.  \  |
//	.    \|
//	0-----2
	n=0;

	for(z=0; z<m_TileN; ++z)
	{
		for(x=0;x<m_TileN; ++x)
		{
			int _0 = (m_TileN+1)*(z+0) +x;
			int _1 = (m_TileN+1)*(z+1) +x;
			int _2 = (m_TileN+1)*(z+0) +x +1;
			int _3 = (m_TileN+1)*(z+1) +x +1;


			m_pFce[n] = VtxIdx(_0, _1, _2);
			++n;
			m_pFce[n] = VtxIdx(_3, _2, _1);
			++n;
		}
	}


	for(z=0; z<=m_TileN; ++z)
	{
		for(x=0;x<=m_TileN; ++x)
		{
			n = z * (m_TileN+1) + x;

			m_pVtx[n].p = D3DXVECTOR3( FLOAT(x), 0.F, FLOAT(z));
			m_pVtx[n].p *= m_TileW;

			m_pVtx[n].u = FLOAT(x)/m_TileN;
			m_pVtx[n].v = 1.f - FLOAT(z)/m_TileN;
		}
	}
	



	FILE* fp;

	fp = fopen(sRaw, "rb");
	if(!fp)
		return -1;

	fseek(fp, 0, SEEK_END);
	long lSize = ftell(fp);

	fseek(fp, 0, SEEK_SET);
	BYTE* pH = new BYTE[lSize];

	fread(pH, lSize, 1, fp);
	fclose(fp);


	for(z=0; z<=m_TileN; ++z)
	{
		for(x=0;x<=m_TileN; ++x)
		{
			FLOAT h;
			n = z * (m_TileN+1) + x;
			h = pH[n]*m_fHscl;
			m_pVtx[n].p.y = h;

			DWORD d;

			if( h < 1.f )
				d = D3DCOLOR_XRGB(255, 249, 157);
			else if( h < 45.0f )
				d = D3DCOLOR_XRGB(124, 197, 118);
			else if( h < 85.5f )
				d = D3DCOLOR_XRGB(  0, 166,  81);
			else if( h < 120.0f )
				d = D3DCOLOR_XRGB( 25, 123,  48);
			else if( h < 170.5f )
				d = D3DCOLOR_XRGB(115, 100,  87);
			else
				d = D3DCOLOR_XRGB(255, 255, 255);

			m_pVtx[n].d = d;
		}
	}

	delete [] pH;

	D3DXCreateTextureFromFile(m_pDev, sTexture, &m_pTx);

	return 0;
}


void CMcField::Destroy()
{
	SAFE_DELETE_ARRAY(	m_pVtx	);
	SAFE_DELETE_ARRAY(	m_pFce	);
	SAFE_RELEASE(	m_pTx	);
}


INT	CMcField::FrameMove()
{
	
	return 1;
}

void CMcField::Render()
{
	m_pDev->SetRenderState( D3DRS_LIGHTING,  FALSE);
	m_pDev->SetRenderState( D3DRS_CULLMODE,  D3DCULL_NONE);
	m_pDev->SetRenderState( D3DRS_ALPHABLENDENABLE,  FALSE);
	m_pDev->SetRenderState( D3DRS_ALPHATESTENABLE,  FALSE);

	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);


	m_pDev->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
	m_pDev->SetTextureStageState(0, D3DTSS_COLORARG2, D3DTA_DIFFUSE);
	m_pDev->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_MODULATE);
	
	
	m_pDev->SetTexture(0, m_pTx);
	m_pDev->SetFVF(VtxDUV1::FVF);

	m_pDev->DrawIndexedPrimitiveUP(
		D3DPT_TRIANGLELIST
		, 0
		, m_nVtx
		, m_nFce
		, m_pFce
		, D3DFMT_INDEX16
		, m_pVtx, sizeof(VtxDUV1));

	m_pDev->SetTexture(0,0);
	m_pDev->SetRenderState( D3DRS_FILLMODE, D3DFILL_SOLID);
	m_pDev->SetRenderState( D3DRS_CULLMODE,  D3DCULL_CCW);
	m_pDev->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_MODULATE);
}

