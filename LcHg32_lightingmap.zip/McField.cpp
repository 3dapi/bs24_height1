// Implementation of the CMcField class.
//
////////////////////////////////////////////////////////////////////////////////


#pragma warning( disable : 4996)

#include <windows.h>
#include <stdio.h>
#include <d3d9.h>
#include <d3dx9.h>

#include "dxutil.h"

#include "McField.h"


CMcField::CMcField()
{
	m_pVtx	= NULL;
	m_pFce	= NULL;

	m_TileN	= 0;
	m_TileW	= 0;

	m_nVtx	= 0;
	m_nFce	= 0;

	m_pTxLgt = 0;
}


CMcField::~CMcField()
{
	Destroy();
}


INT CMcField::Create(LPDIRECT3DDEVICE9 pDev)
{
	m_pDev	= pDev;

	int x;
	int z;
	int n;
	INT	nVtxT;		// �࿡ ���� ���ؽ� ��

	m_TileN = 128;
	m_TileW = 4.f;

	nVtxT	= m_TileN+1;
	m_nVtx	= nVtxT * nVtxT;
	m_nFce	= 2* m_TileN * m_TileN;


	m_pVtx = new VtxNDUV1[m_nVtx];
	m_pFce = new VtxIdx[m_nFce];


	// 1. ������ �ε��� ����
	
//	1-----3
//	.\    |
//	.  \  |
//	.    \|
//	0-----2
	n=0;

	for(z=0; z<m_TileN; ++z)
	{
		for(x=0;x<m_TileN; ++x)
		{
			int _0 = nVtxT*(z+0) +x;
			int _1 = nVtxT*(z+1) +x;
			int _2 = nVtxT*(z+0) +x +1;
			int _3 = nVtxT*(z+1) +x +1;


			m_pFce[n] = VtxIdx(_0, _1, _2);
			++n;
			m_pFce[n] = VtxIdx(_3, _2, _1);
			++n;
		}
	}


	for(z=0; z<=m_TileN; ++z)
	{
		for(x=0;x<=m_TileN; ++x)
		{
			n = z * nVtxT + x;

			m_pVtx[n].p = D3DXVECTOR3( FLOAT(x), 0.F, FLOAT(z));
			m_pVtx[n].p *= m_TileW;

			m_pVtx[n].u = FLOAT(x)/m_TileN;
			m_pVtx[n].v = 1.f - FLOAT(z)/m_TileN;
		}
	}

	

	//2. ���� ����(Test)
	for(z=0; z<=m_TileN; ++z)
	{
		for(x=0;x<=m_TileN; ++x)
		{
			FLOAT h;
			FLOAT fTx = x-nVtxT/2.f;		// ������ �߽��� X
			FLOAT fTz = z-nVtxT/2.f;		// ������ �߽��� Z

			fTx *= fTx;
			fTz *= fTz;
			fTz += fTx;
			fTz *=-0.0014f;
			h = expf( fTz) *200.f;
//			h = 40*(cosf(x/ FLOAT(m_TileN*.1F) )*cosf(z/ FLOAT(m_TileN*.1F) )+1.0f);

			n = z * nVtxT + x;

			m_pVtx[n].p.y = h;

		}
	}


	//3. ���� ���� ����
	SetupNormal();
	
	//5. ���� ���� Ȯ�ο�
	ExportLightingMap();


	D3DXCreateTextureFromFile(m_pDev, "data/Map_Lgt.bmp", &m_pTxLgt);

	return 0;
}


void CMcField::Destroy()
{
	SAFE_DELETE_ARRAY(	m_pVtx	);
	SAFE_DELETE_ARRAY(	m_pFce	);

	SAFE_RELEASE(	m_pTxLgt	);
}


INT	CMcField::FrameMove()
{
	
	return 0;
}

void CMcField::Render()
{
//	m_pDev->SetRenderState( D3DRS_FILLMODE, D3DFILL_WIREFRAME);
	m_pDev->SetRenderState( D3DRS_LIGHTING,  FALSE);
	m_pDev->SetRenderState( D3DRS_CULLMODE,  D3DCULL_NONE);
	m_pDev->SetRenderState( D3DRS_ALPHABLENDENABLE,  FALSE);
	m_pDev->SetRenderState( D3DRS_ALPHATESTENABLE,  FALSE);

	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_NONE);

	m_pDev->SetTexture(0, m_pTxLgt);
	m_pDev->SetFVF(VtxNDUV1::FVF);

	m_pDev->DrawIndexedPrimitiveUP(
		D3DPT_TRIANGLELIST
		, 0
		, m_nVtx
		, m_nFce
		, m_pFce
		, D3DFMT_INDEX16
		, m_pVtx, sizeof(VtxNDUV1));



	m_pDev->SetTexture(0, NULL);
	m_pDev->SetTexture(1, NULL);

	m_pDev->SetRenderState( D3DRS_FILLMODE, D3DFILL_SOLID);
	m_pDev->SetRenderState( D3DRS_CULLMODE,  D3DCULL_CCW);
}




void CMcField::SetupNormal()
{
	int x;
	int z;
	int	k;
	int n;
	INT	nVtxT	= m_TileN+1;

	D3DXVECTOR3	Normal(0,0,0);
	D3DXVECTOR3	v0, v1, v2;
	D3DXVECTOR3	Nor;


	for(z=1; z<m_TileN; ++z)
	{
		for(x=1; x<m_TileN; ++x)
		{
			n = z * nVtxT + x;

			INT nIdx[6][3]=
			{
				{ n, n-1       , n-nVtxT   },
				{ n, n-nVtxT   , n-nVtxT+1 },
				{ n, n-nVtxT+1 , n+1       },
				{ n, n+1       , n+nVtxT   },
				{ n, n+nVtxT   , n+nVtxT-1 },
				{ n, n+nVtxT-1 , n-1       },
			};

			Normal = D3DXVECTOR3(0,0,0);

			for(k=0; k<6; ++k)
			{
				v0 = m_pVtx[  nIdx[k][0] ].p;
				v1 = m_pVtx[  nIdx[k][1] ].p;
				v2 = m_pVtx[  nIdx[k][2] ].p;

				CalculateNormal(&Nor, &v0, &v1, &v2);
				Normal +=Nor;
			}

			Normal /=6.f;
			D3DXVec3Normalize(&Normal,&Normal);

			m_pVtx[n].n = Normal;
		}
	}



	//����
	for(z=1; z<m_TileN; ++z)
	{
		x = 0;
		n = z * nVtxT + x;

		INT nIdx[3][3]=
		{
			{ n, n-nVtxT   , n-nVtxT+1 },
			{ n, n-nVtxT+1 , n+1       },
			{ n, n+1       , n+nVtxT   },
		};

		Normal = D3DXVECTOR3(0,0,0);

		for(k=0; k<3; ++k)
		{
			v0 = m_pVtx[  nIdx[k][0] ].p;
			v1 = m_pVtx[  nIdx[k][1] ].p;
			v2 = m_pVtx[  nIdx[k][2] ].p;

			CalculateNormal(&Nor, &v0, &v1, &v2);
			Normal +=Nor;
		}

		Normal /=3.f;
		D3DXVec3Normalize(&Normal,&Normal);

		m_pVtx[n].n = Normal;
	}


	//������
	for(z=1; z<m_TileN; ++z)
	{
		x = m_TileN;
		n = z * nVtxT + x;

		INT nIdx[3][3]=
		{
			{ n, n-1       , n-nVtxT   },
			{ n, n+nVtxT   , n+nVtxT-1 },
			{ n, n+nVtxT-1 , n-1       },
		};

		Normal = D3DXVECTOR3(0,0,0);

		for(k=0; k<3; ++k)
		{
			v0 = m_pVtx[  nIdx[k][0] ].p;
			v1 = m_pVtx[  nIdx[k][1] ].p;
			v2 = m_pVtx[  nIdx[k][2] ].p;

			CalculateNormal(&Nor, &v0, &v1, &v2);
			Normal +=Nor;
		}

		Normal /=3.f;
		D3DXVec3Normalize(&Normal,&Normal);

		m_pVtx[n].n = Normal;
	}



	//�Ʒ�
	for(x=1; x<m_TileN; ++x)
	{
		z = 0;
		n = z * nVtxT + x;

		INT nIdx[3][3]=
		{
			{ n, n+1       , n+nVtxT   },
			{ n, n+nVtxT   , n+nVtxT-1 },
			{ n, n+nVtxT-1 , n-1       },
		};

		Normal = D3DXVECTOR3(0,0,0);

		for(k=0; k<3; ++k)
		{
			v0 = m_pVtx[  nIdx[k][0] ].p;
			v1 = m_pVtx[  nIdx[k][1] ].p;
			v2 = m_pVtx[  nIdx[k][2] ].p;

			CalculateNormal(&Nor, &v0, &v1, &v2);
			Normal +=Nor;
		}

		Normal /=3.f;
		D3DXVec3Normalize(&Normal,&Normal);

		m_pVtx[n].n = Normal;
	}


	//��
	for(x=1; x<m_TileN; ++x)
	{
		z = m_TileN;
		n = z * nVtxT + x;

		INT nIdx[6][3]=
		{
			{ n, n-1       , n-nVtxT   },
			{ n, n-nVtxT   , n-nVtxT+1 },
			{ n, n-nVtxT+1 , n+1       },
		};

		Normal = D3DXVECTOR3(0,0,0);

		for(k=0; k<3; ++k)
		{
			v0 = m_pVtx[  nIdx[k][0] ].p;
			v1 = m_pVtx[  nIdx[k][1] ].p;
			v2 = m_pVtx[  nIdx[k][2] ].p;

			CalculateNormal(&Nor, &v0, &v1, &v2);
			Normal +=Nor;
		}

		Normal /=3.f;
		D3DXVec3Normalize(&Normal,&Normal);

		m_pVtx[n].n = Normal;
	}


	//(0,0)
	{
		x = 0;
		z = 0;
		n = z * nVtxT + x;

		v0 = m_pVtx[  n		 ].p;
		v1 = m_pVtx[  n+1	 ].p;
		v2 = m_pVtx[  n+nVtxT].p;

		CalculateNormal(&Nor, &v0, &v1, &v2);
		m_pVtx[n].n = Nor;
	}


	//(m_TileN,0)
	{
		x = m_TileN;
		z = 0;
		n = z * nVtxT + x;

		INT nIdx[2][3]=
		{
			{ n, n+nVtxT   , n+nVtxT-1 },
			{ n, n+nVtxT-1 , n-1       },
		};

		Normal = D3DXVECTOR3(0,0,0);

		for(k=0; k<2; ++k)
		{
			v0 = m_pVtx[  nIdx[k][0] ].p;
			v1 = m_pVtx[  nIdx[k][1] ].p;
			v2 = m_pVtx[  nIdx[k][2] ].p;

			CalculateNormal(&Nor, &v0, &v1, &v2);
			Normal +=Nor;
		}

		Normal /=2.f;
		D3DXVec3Normalize(&Normal,&Normal);

		m_pVtx[n].n = Normal;
	}


	//(0, m_TileN)
	{
		x = 0;
		z = m_TileN;
		n = z * nVtxT + x;


		INT nIdx[2][3]=
		{
			{ n, n-nVtxT   , n-nVtxT+1 },
			{ n, n-nVtxT+1 , n+1       },
		};

		Normal = D3DXVECTOR3(0,0,0);

		for(k=0; k<2; ++k)
		{
			v0 = m_pVtx[  nIdx[k][0] ].p;
			v1 = m_pVtx[  nIdx[k][1] ].p;
			v2 = m_pVtx[  nIdx[k][2] ].p;

			CalculateNormal(&Nor, &v0, &v1, &v2);
			Normal +=Nor;
		}

		Normal /=2.f;
		D3DXVec3Normalize(&Normal,&Normal);

		m_pVtx[n].n = Normal;
	}


	//(m_TileN, m_TileN)
	{
		x = m_TileN;
		z = m_TileN;
		n = z * nVtxT + x;

		v0 = m_pVtx[  n		 ].p;
		v1 = m_pVtx[  n-1	 ].p;
		v2 = m_pVtx[  n-nVtxT].p;

		CalculateNormal(&Nor, &v0, &v1, &v2);
		m_pVtx[n].n = Nor;
	}

}



void CMcField::ExportLightingMap()
{
	INT x, z, k;
	INT	nVtxT	= m_TileN+1;
	
	// Diffuse �� ����(Test)
	D3DXVECTOR3 vcLght = D3DXVECTOR3(-1,-1,-1);

	for(k=0; k<m_nVtx; ++k)
	{
		D3DXVECTOR3 vcT = m_pVtx[k].n;
		D3DXVECTOR3 vcL = -vcLght;

		FLOAT fLight = D3DXVec3Dot(&vcT, &vcL);

		if(fLight<0.f)
			fLight = 0.f;

		m_pVtx[k].d = D3DXCOLOR(fLight, fLight, fLight, 1);
	}


	LPDIRECT3DTEXTURE9	pTxLgt;

//	m_pDev->CreateTexture( nVtxT, nVtxT, 0, 0, D3DFMT_X8R8G8B8, D3DPOOL_MANAGED, &pTxLgt, NULL);
//	D3DXCreateTexture( m_pDev, nVtxT  , nVtxT  , 0, 0, D3DFMT_X8R8G8B8, D3DPOOL_MANAGED, &pTxLgt);
	D3DXCreateTexture( m_pDev, m_TileN, m_TileN, 0, 0, D3DFMT_X8R8G8B8, D3DPOOL_MANAGED, &pTxLgt);

	D3DSURFACE_DESC Dsc;
	LPDIRECT3DSURFACE9	pSf=NULL;
	D3DLOCKED_RECT lockedRect;


	pTxLgt->GetLevelDesc(0, &Dsc);
	pTxLgt->GetSurfaceLevel(0, &pSf);
	pSf->LockRect(&lockedRect, 0 , 0);



	DWORD* pImg = (DWORD*)lockedRect.pBits;

	memset(pImg, 0, sizeof(DWORD) * Dsc.Width * Dsc.Height);


	for(z=0; z<m_TileN; ++z)
	{
		for(x=0; x<m_TileN; ++x)
		{
			INT		s = z * Dsc.Width + x;
			INT		n = z * nVtxT     + x;
			DWORD	c = m_pVtx[n].d;

			pImg[s] = c;			// �̹��� ���ǽ��� ����
		}
	}

	
	pSf->UnlockRect();
	D3DXSaveSurfaceToFile( "data/Map_Lgt.bmp", D3DXIFF_BMP, pSf, NULL, NULL);

	pSf->Release();
	pTxLgt->Release();


	for(k=0; k<m_nVtx; ++k)
		m_pVtx[k].d = 0xFFFFFFFF;		// ������ ������ ������ ������� ���� ȯ��

}



void CMcField::CalculateNormal(D3DXVECTOR3* pOut
								, D3DXVECTOR3* v0
								, D3DXVECTOR3* v1
								, D3DXVECTOR3* v2)
{
	// Normalvector���
	// 1. D3DXVec3Cross;
	// 2. D3DXVec3Normalize;

	D3DXVECTOR3 n;
	D3DXVECTOR3 A = *v2 - *v0;
	D3DXVECTOR3 B = *v1 - *v0;
	D3DXVec3Cross(&n, &A, &B);
	D3DXVec3Normalize(&n, &n);

	*pOut = n;
}