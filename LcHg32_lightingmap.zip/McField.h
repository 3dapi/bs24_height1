// Interface for the CMcField class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MCFIELD_H_
#define _MCFIELD_H_

class CMcField
{
public:
	struct VtxNDUV1
	{
		D3DXVECTOR3	p;
		D3DXVECTOR3	n;
		DWORD		d;
		FLOAT		u, v;

		VtxNDUV1(): p(0,0,0),n(0,0,0), u(0), v(0), d(0xFFFFFFFF){}
		VtxNDUV1(FLOAT X,FLOAT Y,FLOAT Z
			, FLOAT nX,FLOAT nY,FLOAT nZ
			, FLOAT U, FLOAT V
			, DWORD D=0xFFFFFFFF): p(X,Y,Z),n(nX,nY, nZ), u(U), v(V), d(D){}
		enum	{FVF = (D3DFVF_XYZ|D3DFVF_NORMAL|D3DFVF_DIFFUSE|D3DFVF_TEX1),};
	};
	

	struct VtxIdx
	{
		union	{	struct	{	WORD a;	WORD b;	WORD c;	};	WORD m[3];	};

		VtxIdx()							{	a = 0;	  b = 1;		 c = 2;	}
		VtxIdx(WORD A, WORD B, WORD C)		{	a = A;    b = B;		 c = C;	}
		VtxIdx(WORD* R)						{	a = R[0]; b = R[1];	 c = R[2];	}
		operator WORD* ()					{		return (WORD *) &a;			}
		operator CONST WORD* () const		{		return (CONST WORD *) &a;	}
	};

protected:
	LPDIRECT3DDEVICE9 m_pDev;
	VtxNDUV1*	m_pVtx;
	VtxIdx*		m_pFce;

	int			m_TileN;
	FLOAT		m_TileW;
	int			m_nVtx;
	int			m_nFce;	

	LPDIRECT3DTEXTURE9 m_pTxLgt;

public:
	CMcField();
	virtual ~CMcField();

	INT		Create(LPDIRECT3DDEVICE9 pDev);
	void	Destroy();

	INT		FrameMove();
	void	Render();

protected:
	void	SetupNormal();
	void	ExportLightingMap();
	void	CalculateNormal(D3DXVECTOR3* pOut, D3DXVECTOR3* v0, D3DXVECTOR3* v1, D3DXVECTOR3* v2);
};

#endif