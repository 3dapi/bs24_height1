// Implementation of the CMcField class.
//
////////////////////////////////////////////////////////////////////////////////


#pragma warning( disable : 4996)

#include <windows.h>
#include <stdio.h>
#include <d3d9.h>
#include <d3dx9.h>

#include "dxutil.h"

#include "McField.h"


CMcField::CMcField()
{
	m_pVtx	= NULL;
	m_pFce	= NULL;

	m_TileN	= 0;
	m_TileW	= 0;

	m_nVtx	= 0;
	m_nFce	= 0;
}


CMcField::~CMcField()
{
	Destroy();
}


INT CMcField::Create(LPDIRECT3DDEVICE9 pDev)
{
	m_pDev	= pDev;

	int x;
	int z;
	int n;
	INT	nVtxT;		// �࿡ ���� ���ؽ� ��

	m_TileN = 128;
	m_TileW = 4.f;

	nVtxT	= m_TileN+1;
	m_nVtx	= nVtxT * nVtxT;
	m_nFce	= 2* m_TileN * m_TileN;


	m_pVtx = new VtxND[m_nVtx];
	m_pFce = new VtxIdx[m_nFce];


	// 1. ������ �ε��� ����
	
//	1-----3
//	.\    |
//	.  \  |
//	.    \|
//	0-----2
	n=0;

	for(z=0; z<m_TileN; ++z)
	{
		for(x=0;x<m_TileN; ++x)
		{
			int _0 = nVtxT*(z+0) +x;
			int _1 = nVtxT*(z+1) +x;
			int _2 = nVtxT*(z+0) +x +1;
			int _3 = nVtxT*(z+1) +x +1;


			m_pFce[n] = VtxIdx(_0, _1, _2);
			++n;
			m_pFce[n] = VtxIdx(_3, _2, _1);
			++n;
		}
	}


	for(z=0; z<=m_TileN; ++z)
	{
		for(x=0;x<=m_TileN; ++x)
		{
			n = z * nVtxT + x;

			m_pVtx[n].p = D3DXVECTOR3( FLOAT(x), 0.F, FLOAT(z));
			m_pVtx[n].p *= m_TileW;

		}
	}


	//2. ���� ����(Test)
	for(z=0; z<=m_TileN; ++z)
	{
		for(x=0;x<=m_TileN; ++x)
		{
			FLOAT h;
			FLOAT fTx = x-nVtxT/2.f;		// ������ �߽��� X
			FLOAT fTz = z-nVtxT/2.f;		// ������ �߽��� Z

			fTx *= fTx;
			fTz *= fTz;
			fTz += fTx;
			fTz *=-0.0014f;
			//h = expf( fTz) *200.f;
			h = 40*(cosf(x/ FLOAT(m_TileN*.1F) )*cosf(z/ FLOAT(m_TileN*.1F) )+1.0f);

			n = z * nVtxT + x;

			m_pVtx[n].p.y = h;

		}
	}


	//3. ���� ���� ����
	SetupNormal();
	
	//5. ���� ���� Ȯ�ο�
	SetupNormalTestVtx();

	return 0;
}


void CMcField::Destroy()
{
	SAFE_DELETE_ARRAY(	m_pVtx	);
	SAFE_DELETE_ARRAY(	m_pFce	);
}


INT	CMcField::FrameMove()
{
	
	return 0;
}

void CMcField::Render()
{
//	m_pDev->SetRenderState( D3DRS_FILLMODE, D3DFILL_WIREFRAME);
	m_pDev->SetRenderState( D3DRS_LIGHTING,  FALSE);
	m_pDev->SetRenderState( D3DRS_CULLMODE,  D3DCULL_NONE);
	m_pDev->SetRenderState( D3DRS_ALPHABLENDENABLE,  FALSE);
	m_pDev->SetRenderState( D3DRS_ALPHATESTENABLE,  FALSE);

	m_pDev->SetTexture(0, NULL);

	m_pDev->SetFVF(VtxND::FVF);

	m_pDev->DrawIndexedPrimitiveUP(
		D3DPT_TRIANGLELIST
		, 0
		, m_nVtx
		, m_nFce
		, m_pFce
		, D3DFMT_INDEX16
		, m_pVtx, sizeof(VtxND));



	m_pDev->SetFVF(VtxD::FVF);
	m_pDev->DrawPrimitiveUP(D3DPT_LINELIST, m_nVtx, m_pVtxN, sizeof(VtxD));

	m_pDev->SetTexture(0, NULL);
	m_pDev->SetTexture(1, NULL);

	m_pDev->SetRenderState( D3DRS_FILLMODE, D3DFILL_SOLID);
	m_pDev->SetRenderState( D3DRS_CULLMODE,  D3DCULL_CCW);
}




void CMcField::SetupNormal()
{
	int x, z, n;

	D3DXVECTOR3	Normal(0,0,0);
	D3DXVECTOR3	v0, v1, v2;

	for(z=0; z<m_TileN; ++z)
	{
		for(x=0; x<m_TileN; ++x)
		{
			n = z * (m_TileN+1) + x;

			v0 = m_pVtx[  n             ].p;
			v1 = m_pVtx[  n+1           ].p;
			v2 = m_pVtx[  n + m_TileN+1 ].p;

			CalculateNormal(&Normal, &v0, &v1, &v2);
			D3DXVec3Normalize(&Normal,&Normal);

			m_pVtx[n].n = Normal;
		}
	}

	// right: copy z-1 to z
	for(z=0; z<m_TileN; ++z)
	{
		n = z * (m_TileN+1) + m_TileN;
		m_pVtx[n].n = m_pVtx[n-1].n;
	}

	// top: copy x-1 to x
	for(x=0; x<=m_TileN; ++x)
	{
		n = m_TileN * (m_TileN+1) + x;
		m_pVtx[n].n = m_pVtx[n-(m_TileN+1)].n;
	}
}



void CMcField::SetupNormalTestVtx()
{
	int k;
	
	// Diffuse �� ����(Test)
	D3DXVECTOR3 vcLght = D3DXVECTOR3(-1,-1,-1);

	for(k=0; k<m_nVtx; ++k)
	{
		D3DXVECTOR3 vcT = m_pVtx[k].n;
		D3DXVECTOR3 vcL = -vcLght;

		FLOAT fLight = D3DXVec3Dot(&vcT, &vcL);

		if(fLight<0.f)
			fLight = 0.f;

		m_pVtx[k].d = D3DXCOLOR(fLight, fLight, fLight, 1);
	}

	// ���� ���� Ȯ�ο�
	m_pVtxN = new VtxD[m_nVtx*2];

	for(k=0; k<m_nVtx; ++k)
	{
		m_pVtxN[k*2+0].p = m_pVtx[k].p;
		m_pVtxN[k*2+0].d = 0xFF0000AA;

		m_pVtxN[k*2+1].p = m_pVtx[k].p + m_pVtx[k].n *4.f;
		m_pVtxN[k*2+1].d = 0xFFAAAA00;
	}

}



void CMcField::CalculateNormal(D3DXVECTOR3* pOut
								, D3DXVECTOR3* v0
								, D3DXVECTOR3* v1
								, D3DXVECTOR3* v2)
{
	// Normalvector���
	// 1. D3DXVec3Cross;
	// 2. D3DXVec3Normalize;

	D3DXVECTOR3 n;
	D3DXVECTOR3 A = *v2 - *v0;
	D3DXVECTOR3 B = *v1 - *v0;
	D3DXVec3Cross(&n, &A, &B);
	D3DXVec3Normalize(&n, &n);

	*pOut = n;
}