// Implementation of the CMcField class.
//
////////////////////////////////////////////////////////////////////////////////

#pragma warning( disable : 4996)

#include <windows.h>
#include <d3d9.h>
#include <d3dx9.h>

#include "dxutil.h"

#include "McField.h"


CMcField::CMcField()
{
	m_pVtx	= NULL;
	m_pFce	= NULL;

	m_TileN	= 0;
	m_TileW	= 0;

	m_nVtx	= 0;
	m_nFce	= 0;
}

CMcField::~CMcField()
{
	Destroy();
}


INT CMcField::Create(LPDIRECT3DDEVICE9 pDev)
{
	m_pDev	= pDev;

	int x;
	int z;
	int n;
	
	m_TileN = 128;
	m_TileW = 4.f;

	m_nVtx = (m_TileN+1) * (m_TileN+1);
	m_nFce = 2* m_TileN * m_TileN;


	m_pVtx = new Vtx[m_nVtx];
	m_pFce = new VtxIdx[m_nFce];

	
//	1-----3
//	.\    |
//	.  \  |
//	.    \|
//	0-----2
	n=0;

	for(z=0; z<m_TileN; ++z)
	{
		for(x=0;x<m_TileN; ++x)
		{
			int _0 = (m_TileN+1)*(z+0) +x;
			int _1 = (m_TileN+1)*(z+1) +x;
			int _2 = (m_TileN+1)*(z+0) +x +1;
			int _3 = (m_TileN+1)*(z+1) +x +1;

			m_pFce[n] = VtxIdx(_0, _1, _2);		++n;
			m_pFce[n] = VtxIdx(_3, _2, _1);		++n;
		}
	}


	for(z=0; z<=m_TileN; ++z)
	{
		for(x=0;x<=m_TileN; ++x)
		{
			n = z * (m_TileN+1) + x;

			m_pVtx[n].p = D3DXVECTOR3( FLOAT(x), 0.F, FLOAT(z));
			m_pVtx[n].p *= m_TileW;
		}
	}
	
	return 0;
}


void CMcField::Destroy()
{
	SAFE_DELETE_ARRAY(	m_pVtx	);
	SAFE_DELETE_ARRAY(	m_pFce	);
}


INT	CMcField::FrameMove()
{
	
	return 1;
}

void CMcField::Render()
{
	m_pDev->SetRenderState( D3DRS_FILLMODE, D3DFILL_WIREFRAME);
	m_pDev->SetRenderState( D3DRS_LIGHTING,  FALSE);
	m_pDev->SetRenderState( D3DRS_ALPHABLENDENABLE,  FALSE);
	m_pDev->SetRenderState( D3DRS_ALPHATESTENABLE,  FALSE);

	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	
	m_pDev->SetTexture(0, NULL);
	m_pDev->SetFVF(Vtx::FVF);

//	D3DPRIMITIVETYPE PrimitiveType,
//    UINT MinVertexIndex,
//    UINT NumVertices,
//    UINT PrimitiveCount,
//    const void *pIndexData,
//    D3DFORMAT IndexDataFormat,
//    CONST void* pVertexStreamZeroData,
//    UINT VertexStreamZeroStride

	m_pDev->DrawIndexedPrimitiveUP(
		D3DPT_TRIANGLELIST
		, 0
		, m_nVtx
		, m_nFce
		, m_pFce
		, D3DFMT_INDEX16
		, m_pVtx, sizeof(Vtx));

	m_pDev->SetTexture(0,0);
	m_pDev->SetRenderState( D3DRS_FILLMODE, D3DFILL_SOLID);
}


