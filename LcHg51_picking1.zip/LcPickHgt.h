// Interface for the CLcPickHgt class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LcPickHgt_H_
#define _LcPickHgt_H_


struct LcRect
{
	VtxD	pVtx[4];

	LcRect()
	{
		pVtx[0].d = 0x44FFFF00;
		pVtx[1].d = 0x44FFFF00;
		pVtx[2].d = 0x44FFFF00;
		pVtx[3].d = 0x44FFFF00;

		pVtx[0].p.y = 0.f;
		pVtx[1].p.y = 0.f;
		pVtx[2].p.y = 0.f;
		pVtx[3].p.y = 0.f;
	}
};

typedef vector<LcRect>		lsLcRect;
typedef lsLcRect::iterator	itLcRect;


class CLcPickHgt
{
protected:
	LPDIRECT3DDEVICE9	m_pDev;

	VtxD*		m_pTile;
	VtxD		m_pLine[2];

	FLOAT		m_fW;

	lsLcRect	m_vRc;
	
public:
	CLcPickHgt();
	~CLcPickHgt();

	INT		Create(LPDIRECT3DDEVICE9 pDev);
	void	Destroy();

	INT		FrameMove();
	void	Render();
};

#endif