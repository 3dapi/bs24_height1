#include "_StdAfx.h"


void McUtil_ErrMsgBox(TCHAR *format,...)
{
	va_list ap;
	char s[2048];
	
	if (format == NULL) return;
	
	va_start(ap, format);
	vsprintf((char *)s, format, ap);
	va_end(ap);
	
	if (s == NULL)	return;
	
	MessageBox(NULL, s, "Err", MB_OK | MB_ICONERROR);
}


void McUtil_SetWindowTitle(TCHAR *format,...)
{
	va_list ap;
	char s[2048];
	
	if (format == NULL) return;
	
	va_start(ap, format);
	vsprintf((char *)s, format, ap);
	va_end(ap);
	
	if (s == NULL)	return;
	
	// �̷��� ���������� �ʿ��� ���̴�.
	SetWindowText(GHWND, s);
}

