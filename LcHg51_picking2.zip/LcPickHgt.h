// Interface for the CLcPickHgt class.
// PickHgtham Picking
////////////////////////////////////////////////////////////////////////////////

#ifndef _LcPickHgt_H_
#define _LcPickHgt_H_

template<class T>
struct TsrtG
{
	bool operator()(const T& t1, const T& t2)
	{
		return (t1.fR < t2.fR);
	}
};

struct LcRect
{
	VtxD	pVtx[4];

	LcRect()
	{
		pVtx[0].d = 0x44FFFF00;
		pVtx[1].d = 0x44FFFF00;
		pVtx[2].d = 0x44FFFF00;
		pVtx[3].d = 0x44FFFF00;
	}
};

typedef vector<LcRect >		lsLcRect;
typedef lsLcRect::iterator	itLcRect;


struct LcPck
{
	VtxD	pVtx[3];
	FLOAT	fR;
	VEC3	vcP;

	LcPck()
	{
		pVtx[0].d = 0xFFFF00FF;
		pVtx[1].d = 0xFFFF00FF;
		pVtx[2].d = 0xFFFF00FF;
	}
};

typedef vector<LcPck >		lsPck;


class CLcPickHgt
{
protected:
	LPDIRECT3DDEVICE9	m_pDev;

	VtxD		m_pLine[2];

	FLOAT		m_fW;


	lsLcRect	m_vRc;
	lsPck		m_vVc;


	INT			m_iNx;					// X�� �� ���� ��
	INT			m_iNz;					// Z�� �� ���� ��
	INT			m_iNv;					// ��ü ���� ��
	VtxD*		m_pVc;					// Vertex Buffer

	INT			m_iNfc;					// �ﰢ���� ��
	VtxIdx*		m_pVi;					// Index Buffer
	
public:
	CLcPickHgt();
	~CLcPickHgt();

	INT		Create(LPDIRECT3DDEVICE9 pDev);
	void	Destroy();

	INT		FrameMove();
	void	Render();
};

#endif