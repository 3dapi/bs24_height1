// Implementation of the CLcPickHgt class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CLcPickHgt::CLcPickHgt()
{
	m_pVc = NULL;
	m_pVi = NULL;
}

CLcPickHgt::~CLcPickHgt()
{
	Destroy();
}


INT CLcPickHgt::Create(LPDIRECT3DDEVICE9 pDev)
{
	m_pDev = pDev;

	int		x, z;

	m_fW	= 32;
	m_iNx	= 32+1;
	m_iNz	= 32+1;
	m_iNv	= m_iNx * m_iNz * 3 * 2;


	m_pLine[0].p = D3DXVECTOR3(  600, 0, -20);
	m_pLine[1].p = D3DXVECTOR3(  -10, 0,  20);

	m_pLine[0].p = D3DXVECTOR3(  -10, 0, -10);
	m_pLine[1].p = D3DXVECTOR3(  300, 0, 280);



	m_pVc = new VtxD[m_iNv];

	// Fill Vertex buffer
	for(z=0; z<m_iNz; ++z)
	{
		for(x=0; x<m_iNx; ++x)
		{
			int idx = z * m_iNx + x;
			FLOAT fH = (x-m_iNx/2)*(x-m_iNx/2) + (z-m_iNx/2) * (z-m_iNx/2);
			
			fH *= 0.02f;
			fH = 300.f * exp(-fH);
//			fH	= rand()%128;

			m_pVc[idx] = VtxD( x * m_fW
							, fH
							, z * m_fW
							, 0xFF0088DD);
		}
	}



	m_iNfc = (m_iNx-1) * (m_iNz-1) * 2;				// �ﰢ���� ��

	m_pVi = new VtxIdx[m_iNfc];

	// Fill Index buffer
	int k=0;
	for(z=0; z<m_iNz-1; ++z)
	{
		for(x=0; x<m_iNx-1; ++x)
		{
			int idx0 = (z+0) * m_iNx + x;

			m_pVi[k] = VtxIdx(idx0, idx0+m_iNx, idx0+1);
			++k;

			int idx1 = (z+1) * m_iNx + x+1;
			m_pVi[k] = VtxIdx(idx1, idx1-m_iNx, idx1-1);
			++k;
		}
	}

	return 1;
}


void CLcPickHgt::Destroy()
{
	SAFE_DELETE_ARRAY(	m_pVc	);
	SAFE_DELETE_ARRAY(	m_pVi	);
}


INT	CLcPickHgt::FrameMove()
{
	D3DXVECTOR3 vcCamPos;
	D3DXVECTOR3 vcRayDir;


	vcCamPos = GCAM->GetCamPos();


	FLOAT fMouseX = (FLOAT)GINPUT->GetMousePos().x;
	FLOAT fMouseY = (FLOAT)GINPUT->GetMousePos().y;
	GCAM->GetPickLayDirection(&vcRayDir, fMouseX, fMouseY);


	m_pLine[0].p = vcCamPos;
	m_pLine[1].p = vcCamPos + vcRayDir*100000;
	m_pLine[0].p.y =0;
	m_pLine[1].p.y =0;


	m_vRc.clear();

	D3DXVECTOR3	vcD = m_pLine[1].p- m_pLine[0].p;

	FLOAT	fA;
	FLOAT	fB;
	
	if(0.f == vcD.x)
		fA = FLT_MAX;
	
	else
		fA= vcD.z/vcD.x;

	fA = fA;
	fB = m_pLine[0].p.z - fA * m_pLine[0].p.x;

	for(int i=0; i<m_iNx; ++i)
	{
		FLOAT	x;
		FLOAT	z;

		
		x = i* m_fW;
		z = fA* i + fB/m_fW;
		z = floorf(z);
		
		if( z>=0 && z<(m_iNx-1) && i<(m_iNx-1))
		{
			LcRect	rc;
			rc.pVtx[0].p = m_pVc[(INT(z)+0)* m_iNx + i ].p;
			rc.pVtx[1].p = m_pVc[(INT(z)+1)* m_iNx + i ].p;
			rc.pVtx[2].p = m_pVc[(INT(z)+0)* m_iNx + i + 1].p;
			rc.pVtx[3].p = m_pVc[(INT(z)+1)* m_iNx + i + 1].p;

			if( fabsf(rc.pVtx[0].p.x - rc.pVtx[3].p.x) <=m_fW &&
				fabsf(rc.pVtx[0].p.z - rc.pVtx[3].p.z) <=m_fW)
				m_vRc.push_back(rc);
		}



		z = i * m_fW;
		x = (m_fW * i - fB)/(fA*m_fW);
		x = floorf(x);

		if( x>=0 && x<(m_iNx-1))
		{
			if(fA>=0)
			{
				LcRect	rc;
				rc.pVtx[0].p = m_pVc[(INT(i)+0)* m_iNx + INT(x) ].p;
				rc.pVtx[1].p = m_pVc[(INT(i)+1)* m_iNx + INT(x) ].p;
				rc.pVtx[2].p = m_pVc[(INT(i)+0)* m_iNx + INT(x) + 1].p;
				rc.pVtx[3].p = m_pVc[(INT(i)+1)* m_iNx + INT(x) + 1].p;

				if( fabsf(rc.pVtx[0].p.x - rc.pVtx[3].p.x) <=m_fW &&
					fabsf(rc.pVtx[0].p.z - rc.pVtx[3].p.z) <=m_fW)
					m_vRc.push_back(rc);
			}

			else if(z>0)
			{
				LcRect	rc;
				z = (i-1);
				rc.pVtx[0].p = m_pVc[(INT(z)+0)* m_iNx + INT(x) ].p;
				rc.pVtx[1].p = m_pVc[(INT(z)+1)* m_iNx + INT(x) ].p;
				rc.pVtx[2].p = m_pVc[(INT(z)+0)* m_iNx + INT(x) + 1].p;
				rc.pVtx[3].p = m_pVc[(INT(z)+1)* m_iNx + INT(x) + 1].p;

				if( fabsf(rc.pVtx[0].p.x - rc.pVtx[3].p.x) <=m_fW &&
					fabsf(rc.pVtx[0].p.z - rc.pVtx[3].p.z) <=m_fW)
					m_vRc.push_back(rc);
			}
		}
	}


	if(!m_vRc.empty())
	{
		m_vVc.clear();

		INT iSize = m_vRc.size();

		for(int i=0; i<iSize; ++i)
		{
			D3DXVECTOR3	V0, V1, V2;
			FLOAT	U, V, D;
			
			V0 = m_vRc[i].pVtx[0].p;
			V1 = m_vRc[i].pVtx[1].p;
			V2 = m_vRc[i].pVtx[2].p;

			if(	D3DXIntersectTri( &V0, &V1, &V2, &vcCamPos, &vcRayDir, &U, &V, &D))
			{
				LcPck	Pck;

				// Pick Position
				Pck.vcP = V0 + U * (V1-V0) + V * (V2-V0);

				Pck.pVtx[0].p = V0;
				Pck.pVtx[1].p = V1;
				Pck.pVtx[2].p = V2;
				Pck.fR	= D;

				m_vVc.push_back( Pck );
			}

			V0 = m_vRc[i].pVtx[3].p;
			V1 = m_vRc[i].pVtx[2].p;
			V2 = m_vRc[i].pVtx[1].p;

			if(	D3DXIntersectTri( &V0, &V1, &V2, &vcCamPos, &vcRayDir, &U, &V, &D))
			{
				LcPck	Pck;

				// Pick Position
				Pck.vcP = V0 + U * (V1-V0) + V * (V2-V0);

				Pck.pVtx[0].p = V0;
				Pck.pVtx[1].p = V1;
				Pck.pVtx[2].p = V2;
				Pck.fR	= D;

				m_vVc.push_back( Pck );
			}
		}

		if(!m_vVc.empty())
		{
			sort(m_vVc.begin(), m_vVc.end(), TsrtG<LcPck >());
		}
	}
	
	return 1;
}

void CLcPickHgt::Render()
{
	m_pDev->SetRenderState(D3DRS_FILLMODE, D3DFILL_WIREFRAME);
	m_pDev->SetRenderState( D3DRS_LIGHTING,  FALSE);
	m_pDev->SetRenderState( D3DRS_ALPHABLENDENABLE,  FALSE);
	m_pDev->SetRenderState( D3DRS_ALPHATESTENABLE,  FALSE);
	m_pDev->SetRenderState( D3DRS_ZENABLE, FALSE);
	
	m_pDev->SetTexture(0, 0);
	m_pDev->SetFVF(VtxD::FVF);
	m_pDev->DrawPrimitiveUP(D3DPT_LINELIST, 1, m_pLine, sizeof(VtxD));

	m_pDev->SetFVF(VtxD::FVF);
	m_pDev->DrawIndexedPrimitiveUP(D3DPT_TRIANGLELIST, 0, m_iNv, m_iNfc, m_pVi, D3DFMT_INDEX16, m_pVc, sizeof(VtxD));


	VtxD	pVtx[4];
	int iSize = m_vRc.size();

	McUtil_SetWindowTitle("%d", iSize);

	for(int i=0; i<iSize; ++i)
	{
		pVtx[0] = m_vRc[i].pVtx[0];
		pVtx[1] = m_vRc[i].pVtx[1];
		pVtx[2] = m_vRc[i].pVtx[2];
		pVtx[3] = m_vRc[i].pVtx[3];

		
		
		m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, m_vRc[i].pVtx, sizeof(VtxD));
	}

	if(!m_vVc.empty())
	{
		m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 1, m_vVc[0].pVtx, sizeof(VtxD));
	}

	m_pDev->SetRenderState( D3DRS_FILLMODE, D3DFILL_SOLID);

	m_pDev->SetRenderState( D3DRS_ZENABLE, TRUE);
}
