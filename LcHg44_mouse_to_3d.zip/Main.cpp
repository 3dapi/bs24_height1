// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMain::CMain()
{
	m_pD3DXFont		= NULL;
	m_pD3DXFont2	= NULL;
	m_pInput		= NULL;
	m_pGrid			= NULL;
	m_pCam			= NULL;
}


HRESULT CMain::Init()
{
	D3DXFONT_DESC hFont =
	{
		14, 0
		, FW_BOLD, 1, FALSE
		, HANGUL_CHARSET
		, OUT_DEFAULT_PRECIS, ANTIALIASED_QUALITY, FF_DONTCARE
		, "Arial"
	};

	if( FAILED( D3DXCreateFontIndirect(m_pd3dDevice, &hFont, &m_pD3DXFont) ) )
		return -1;

	hFont.Height = 20;
	if( FAILED( D3DXCreateFontIndirect(m_pd3dDevice, &hFont, &m_pD3DXFont2) ) )
		return -1;


	// Input ����
	m_pInput = new CMcInput;
	m_pInput->Create(m_hWnd);

	// Grid����
	m_pGrid = new CMcGrid;
	m_pGrid->Create(m_pd3dDevice);

	// ī�޶� ����
	m_pCam = new CMcCam;
	m_pCam->Create(m_pd3dDevice);


	return S_OK;
}


HRESULT CMain::Destroy()
{
	SAFE_RELEASE( m_pD3DXFont	);
	SAFE_RELEASE( m_pD3DXFont2	);
	SAFE_DELETE(	m_pGrid		);
	SAFE_DELETE(	m_pCam		);
	SAFE_DELETE(	m_pInput	);

	return S_OK;
}


HRESULT CMain::Restore()
{
	m_pD3DXFont->OnResetDevice();
	m_pD3DXFont2->OnResetDevice();

	return S_OK;
}


HRESULT CMain::Invalidate()
{
	m_pD3DXFont->OnLostDevice();
	m_pD3DXFont2->OnLostDevice();

	return S_OK;
}


HRESULT CMain::FrameMove()
{
	m_pInput->FrameMove();

	// Wheel mouse...
	D3DXVECTOR3 vcD = m_pInput->GetMouseEps();

	if(vcD.z !=0.f)
		m_pCam->MoveForward(-vcD.z* .1f, 1.f);

	if(m_pInput->KeyState('W'))					// W
		m_pCam->MoveForward( 4.f, 1.f);

	if(m_pInput->KeyState('S'))					// S
		m_pCam->MoveForward(-4.f, 1.f);

	if(m_pInput->KeyState('A'))					// A
		m_pCam->MoveSide(-4.f);

	if(m_pInput->KeyState('D'))					// D
		m_pCam->MoveSide(4.f);
	

	if(m_pInput->BtnPress(1))
	{
		D3DXVECTOR3 vcDelta = m_pInput->GetMouseEps();
		m_pCam->Rotation(vcDelta);		
	}

	m_pCam->FrameMove();

	return S_OK;
}


HRESULT CMain::Render()
{
	m_pd3dDevice->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER|D3DCLEAR_STENCIL, 0xFF006699, 1.0f, 0L);

	if( FAILED( m_pd3dDevice->BeginScene() ) )
		return -1;


	// ī�޶� Ŭ������ �Լ� ȣ��
	m_pCam->SetTransform();


	
	//�׸��带 �׸���.
	m_pGrid->Render();





	m_pd3dDevice->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
	m_pd3dDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);

	RenderText();

	m_pd3dDevice->EndScene();

	return S_OK;
}



D3DXVECTOR3 GetMouse3DPosition(LPDIRECT3DDEVICE9 pDev, FLOAT mouseX, FLOAT mouseY)
{
	D3DXVECTOR3 	vcPick;
	D3DXVECTOR3 	vcPickDir;

	D3DXMATRIX		mtViw;
	D3DXMATRIX		mtViwI;
	D3DXMATRIX		mtPrj;
	D3DVIEWPORT9    vp;

	D3DXVECTOR3 	vcCamP;		// camera position
	D3DXVECTOR3		vcCamX;		// camera x axis
	D3DXVECTOR3		vcCamY;		// camera y axis
	D3DXVECTOR3		vcCamZ;		// camera z axis

	// ����Ʈ, �� ���, ���� ����� ���´�.
	pDev->GetViewport(&vp);
	pDev->GetTransform(D3DTS_VIEW, &mtViw);
	pDev->GetTransform(D3DTS_PROJECTION, &mtPrj);

	// �� ����� �� ���
	D3DXMatrixInverse(&mtViwI, NULL, &mtViw);

	// camera position, x, y, z axis
	vcCamP = D3DXVECTOR3(mtViwI._41, mtViwI._42, mtViwI._43);
	vcCamX = D3DXVECTOR3(mtViwI._11, mtViwI._12, mtViwI._13);
	vcCamY = D3DXVECTOR3(mtViwI._21, mtViwI._22, mtViwI._23);
	vcCamZ = D3DXVECTOR3(mtViwI._31, mtViwI._32, mtViwI._33);


	// Get the pick ray from the mouse position
	FLOAT fW    = (FLOAT)vp.Width;			// ȭ�� �ʺ�
	FLOAT fH    = (FLOAT)vp.Height;			// ȭ�� ����

	FLOAT w     =  mtPrj._11;
	FLOAT h     =  mtPrj._22;
	FLOAT fNear = -mtPrj._43/mtPrj._33;		// Near Value....

	// [-1,1]�� ����ȭ
	FLOAT viw_x =  ( 2.f * mouseX / fW - 1 ) / w;
	FLOAT viw_y = -( 2.f * mouseY / fH - 1 ) / h;
	FLOAT viw_z =  fNear;

	viw_x *= fNear;
	viw_y *= fNear;

	vcPick = vcCamP + viw_x * vcCamX + viw_y * vcCamY + viw_z * vcCamZ;

	return vcPick;



	// Transform the screen space pick ray into 3D space
	// Ray Direction
	// vcPick = D3DXVECTOR3(viw_x, viw_y, viw_z);
	//vcPickDir	.x  = D3DXVec3Dot(&vcPick, &D3DXVECTOR3(mtViwI._11, mtViwI._21, mtViwI._31));
	//vcPickDir.y  = D3DXVec3Dot(&vcPick, &D3DXVECTOR3(mtViwI._12, mtViwI._22, mtViwI._32));
	//vcPickDir.z  = D3DXVec3Dot(&vcPick, &D3DXVECTOR3(mtViwI._13, mtViwI._23, mtViwI._33));
	//vcPick = vcCamP + vcPickDir;
	// return vcPick;
}




// ����Ʈ ���
void D3DXMatrixViewport(D3DXMATRIX* pOut, const D3DVIEWPORT9* pV /*Viewport*/)
    {
    float   fW = 0;
    float   fH = 0;
    float   fD = 0;
    float   fY = 0;
    float   fX = 0;

    float   fM = FLOAT(pV->MinZ);

    fW = FLOAT(pV->Width)*.5f;
    fH = FLOAT(pV->Height)*.5f;
    fD = FLOAT(pV->MaxZ) - FLOAT(pV->MinZ);
    fX = FLOAT(pV->X) + fW;
    fY = FLOAT(pV->Y) + fH;

    *pOut = D3DXMATRIX( fW,  0.f,  0, 0,
                       0.f,  -fH,  0, 0,
                       0.f,  0.f, fD, 0,
                       fX,    fY, fM, 1);
}


D3DXVECTOR3 GetMouse3DPositionUnTM(LPDIRECT3DDEVICE9 pDev, FLOAT mouseX, FLOAT mouseY)
{
	D3DXVECTOR3 	vcPick;

	D3DXMATRIX		mtViw;
	D3DXMATRIX		mtPrj;
	D3DVIEWPORT9    vp;
	D3DXMATRIX		mtVpt;	// ����Ʈ ���

	pDev->GetViewport(&vp);
	D3DXMatrixViewport(&mtVpt, &vp);

	pDev->GetTransform(D3DTS_VIEW, &mtViw);
	pDev->GetTransform(D3DTS_PROJECTION, &mtPrj);

	// ��ȯ ��� = ���� ��� * ����� * ���� ��� * ����Ʈ ���
	D3DXMATRIX  mtTMpt  = mtViw * mtPrj * mtVpt;
	D3DXMATRIX  mtTMptI;

	// ��ȯ ����� ������� ���Ѵ�.
	D3DXMatrixInverse(&mtTMptI, NULL, &mtTMpt);


	// ��ũ�� ��ǥ ����
	// Near ����� ������ ������ȯ �� ���̰� 0(=z)
	vcPick = D3DXVECTOR3(mouseX, mouseY, 0);

	// �ռ� ���� ������� �̿��ؼ� 3���� ��ǥ�� �����.
	D3DXVec3TransformCoord(&vcPick, &vcPick, &mtTMptI);



	//// ����Ʈ�� �� ��ȯ
	//D3DXMATRIX mtVptI;
	//D3DXMatrixInverse(&mtVptI, NULL, &mtVpt);
	//D3DXVec3TransformCoord(&vcT, &vcPick, &mtVptI);
	//
	//
	//// ������ �� ��ȯ
	//D3DXMATRIX mtPrjI;
	//D3DXMatrixInverse(&mtPrjI, NULL, &mtPrj);
	//D3DXVec3TransformCoord(&vcT, &vcT, &mtPrjI);
	//
	//
	//// ������ �� ��ȯ
	//D3DXMATRIX mtViwI;
	//D3DXMatrixInverse(&mtViwI, NULL, &mtViw);
	//D3DXVec3TransformCoord(&vcPick, &vcT, &mtViwI);

	return vcPick;
}


D3DXVECTOR3 GetMouse3DPositionDXUnProjection(LPDIRECT3DDEVICE9 pDev, FLOAT mouseX, FLOAT mouseY)
{
	D3DXVECTOR3 	vcPick;

	D3DXMATRIX		mtViw;
	D3DXMATRIX		mtPrj;
	D3DVIEWPORT9    vp;
	D3DXMATRIX		mtVpt;// ����Ʈ ���

	pDev->GetViewport(&vp);
	D3DXMatrixViewport(&mtVpt, &vp);

	pDev->GetTransform(D3DTS_VIEW, &mtViw);
	pDev->GetTransform(D3DTS_PROJECTION, &mtPrj);

	// ��ũ�� ��ǥ ����
	// Near ����� ������ ������ȯ �� ���̰� 0(=z)
	vcPick = D3DXVECTOR3(mouseX, mouseY, 0);

	D3DXVec3Unproject(&vcPick, &vcPick, &vp, &mtPrj, &mtViw, NULL);

	return vcPick;
}




	
HRESULT CMain::RenderText()
{
	m_pd3dDevice->SetRenderState(D3DRS_LIGHTING, FALSE);
	m_pd3dDevice->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
	m_pd3dDevice->SetTexture( 0, 0);

	CHAR szMsg[MAX_PATH];
	RECT rc;
	rc.left   = 2;
	rc.right  = m_d3dsdBackBuffer.Width - 20;
	rc.top = 3;
	rc.bottom = rc.top + 20;

	sprintf(szMsg, "%s %s",m_strDeviceStats, m_strFrameStats );

	m_pD3DXFont->DrawText(NULL, szMsg, -1, &rc, 0, D3DXCOLOR(1,1,0,1) );


	rc.top += 23;
	rc.bottom = rc.top + 20;


	D3DXMATRIX	mtViw = m_pCam->GetViewMatrix();
	D3DXMatrixInverse(&mtViw, NULL, &mtViw);

	D3DXVECTOR3 vcCamPos(mtViw._41, mtViw._42, mtViw._43);
	sprintf(szMsg, "Camera Pos: %.f %.f %.f",vcCamPos.x, vcCamPos.y, vcCamPos.z );
	m_pD3DXFont->DrawText(NULL, szMsg, -1, &rc, 0, D3DXCOLOR(1,1,0,1) );



	D3DXVECTOR3 vcMouse = m_pInput->GetMousePos();
	
	
	D3DXVECTOR3 vcScn1 = GetMouse3DPosition(m_pd3dDevice, vcMouse.x, vcMouse.y);
	rc.top = 100;
	rc.bottom = rc.top + 20;
	sprintf(szMsg, "3D Mouse Position: %f %f %f - (Manual)",vcScn1.x, vcScn1.y, vcScn1.z );
	m_pD3DXFont2->DrawText(NULL, szMsg, -1, &rc, 0, D3DXCOLOR(1,0,1,1) );


	D3DXVECTOR3 vcScn2 = GetMouse3DPositionUnTM(m_pd3dDevice, vcMouse.x, vcMouse.y);
	rc.top = 125;
	rc.bottom = rc.top + 20;
	sprintf(szMsg, "3D Mouse Position: %f %f %f - (UnProjection)",vcScn2.x, vcScn2.y, vcScn2.z );
	m_pD3DXFont2->DrawText(NULL, szMsg, -1, &rc, 0, D3DXCOLOR( 0,1,1,1) );


	D3DXVECTOR3 vcScn3 = GetMouse3DPositionDXUnProjection(m_pd3dDevice, vcMouse.x, vcMouse.y);
	rc.top = 150;
	rc.bottom = rc.top + 20;
	sprintf(szMsg, "3D Mouse Position: %f %f %f - (DXUnProjection)",vcScn3.x, vcScn3.y, vcScn3.z );
	m_pD3DXFont2->DrawText(NULL, szMsg, -1, &rc, 0, D3DXCOLOR( 0,1,0,1) );
	


	return S_OK;
}







LRESULT CMain::MsgProc( HWND hWnd, UINT msg, WPARAM wParam,LPARAM lParam)
{
	WPARAM	wparHi;
	WPARAM	wparLo;

	wparHi = HIWORD(wParam);
	wparLo = LOWORD(wParam);

	switch( msg )
	{
		case WM_PAINT:
		{
			if( m_bLoadingApp )
			{
				HDC hDC = GetDC( hWnd );
				CHAR strMsg[MAX_PATH];
				RECT rc;
				wsprintf( strMsg, TEXT("Loading... Please wait") );
				GetClientRect( hWnd, &rc );
				DrawText( hDC, strMsg, -1, &rc, DT_CENTER|DT_VCENTER|DT_SINGLELINE );
				ReleaseDC( hWnd, hDC );
			}
			break;
		}

	}

	return CD3DApplication::MsgProc( hWnd, msg, wParam, lParam );
}









































