//
//
////////////////////////////////////////////////////////////////////////////////

#pragma warning( disable : 4018)
#pragma warning( disable : 4098)
#pragma warning( disable : 4100)
#pragma warning( disable : 4238)
#pragma warning( disable : 4245)
#pragma warning( disable : 4503)
#pragma warning( disable : 4663)
#pragma warning( disable : 4786)
#pragma warning( disable : 4996)

#pragma once


#ifndef __STDAFX_H_
#define __STDAFX_H_


#pragma comment(lib, "dinput8.lib")

#define STRICT
#define _WIN32_WINNT			0x0400
#define DIRECTINPUT_VERSION		0x0800

#include <vector>
#include <list>
#include <map>
#include <cstdlib>
#include <ctime>
#include <algorithm>
#include <functional>

using namespace std;


#include <windows.h>
#include <windowsx.h>
#include <mmsystem.h>

#include <commctrl.h>
#include <commdlg.h>
#include <basetsd.h>

#include <math.h>
#include <stdio.h>
#include <tchar.h>

#include <d3d9.h>
#include <d3dx9.h>
#include <DxErr.h>

#include <dinput.h>

#include "D3DUtil.h"
#include "DXUtil.h"

#include "D3DEnum.h"
#include "D3DSetting.h"
#include "D3DApp.h"
#include "resource.h"

#define GMAIN		g_pApp
#define GHINST		g_pApp->m_hInst
#define GHWND		g_pApp->m_hWnd

#define GDEVICE		g_pApp->m_pd3dDevice
#define GSPRITE		g_pApp->m_pd3dSprite
#define GSURFACE	g_pApp->m_pd3dSf

#define GINPUT		g_pApp->m_pInput
#define GCAM		g_pApp->m_pCam

#include "VtxFmt.h"
#include "McUtil.h"

#include "McInput.h"
#include "McCam.h"
#include "McGrid.h"




#include "Main.h"


#endif