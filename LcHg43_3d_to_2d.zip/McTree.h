// Interface for the CMcTree class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MCTREE_H_
#define _MCTREE_H_


struct McImage
{
	LPDIRECT3DTEXTURE9	pTx;
	D3DXIMAGE_INFO		Img;
};

struct McBill
{
	INT			nT;			// Texture Index;
	D3DXVECTOR3	vcP;		// Position
	FLOAT		fZ;			// z ���⿡ ���� ī�޶���� �Ÿ�
};

class CMcTree  
{
public:
	struct VtxDUV1
	{
		D3DXVECTOR3	p;
		DWORD		d;
		FLOAT		u,v;

		VtxDUV1() : p(0,0,0),u(0),v(0), d(0xFFFFFFFF){}

		VtxDUV1( FLOAT X, FLOAT Y, FLOAT Z
				, FLOAT U, FLOAT V, DWORD D=0xffffffff): p(X,Y,Z)
									 , u(U), v(V)
									 , d(D){}

		enum	{FVF = (D3DFVF_XYZ|D3DFVF_DIFFUSE|D3DFVF_TEX1),};
	};

protected:
	LPDIRECT3DDEVICE9	m_pDev;
	McImage				m_pTxTree[3];
	
	INT			m_iN;
	McBill*		m_pBill;
	VtxDUV1*	m_pVtx;
	
public:
	CMcTree();
	virtual ~CMcTree();
	
	INT		Create(LPDIRECT3DDEVICE9 pDev);
	void	Destroy();
	INT		FrameMove();
	void	Render();

	void	RenderIndex(ID3DXFont* pFont);
	int		GetObjNum();

	D3DXVECTOR3	GetObjPos(int i);
	void		SetObjPos(int i, D3DXVECTOR3 vcP);
	
	static int SortFnc (McBill* p1, const McBill* p2)
	{
		FLOAT score1, score2;

		score1 = p1->fZ;
		score2 = p2->fZ;

		if(score1 < score2)
			return 1;

		else if(score1 == score2)
			return 0;

		else 
			return -1;
	}
};

#endif