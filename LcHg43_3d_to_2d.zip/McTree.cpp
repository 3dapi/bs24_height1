// Implementation of the CMcTree class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


TCHAR *sTxName[] =
{
	"Texture/tree01S.dds",
		"Texture/tree02S.dds",
		"Texture/tree35S.dds",
};




CMcTree::CMcTree()
{
}

CMcTree::~CMcTree()
{
	Destroy();
}


INT CMcTree::Create(LPDIRECT3DDEVICE9 pDev)
{
	INT i=0;

	m_pDev = pDev;

	m_iN =100;
	
	for(i=0; i<3; ++i)
	{
		D3DXCreateTextureFromFileEx(
					m_pDev
					, sTxName[i]
					, D3DX_DEFAULT
					, D3DX_DEFAULT
					, D3DX_DEFAULT
					, 0
					, D3DFMT_UNKNOWN
					, D3DPOOL_MANAGED
					, D3DX_DEFAULT
					, D3DX_DEFAULT
					, 0x00FFFFFF
					, &m_pTxTree[i].Img
					, NULL
					, &m_pTxTree[i].pTx);
	}
	
	m_pBill	= new McBill[m_iN];
	m_pVtx	= new VtxDUV1[m_iN * 6];
	
	for(i=0; i<m_iN; ++i)
	{
		m_pBill[i].nT = rand()%(3);
		m_pBill[i].vcP.x = 2.f + rand()%(126);
		m_pBill[i].vcP.z = 2.f + rand()%(126);
		m_pBill[i].vcP.y = 0;

		m_pBill[i].vcP *= 7.8f;
	}
	
	
	return 0;
}


void CMcTree::Destroy()
{
	for(int i=0; i<3; ++i)
		SAFE_RELEASE(	m_pTxTree[i].pTx);
	
	SAFE_DELETE_ARRAY(	m_pBill	);
	SAFE_DELETE_ARRAY(	m_pVtx	);
}


INT CMcTree::FrameMove()
{
	INT	i;
	D3DXMATRIX mtB;
	
	m_pDev->GetTransform(D3DTS_VIEW, &mtB);
	
	D3DXMatrixInverse(&mtB, 0, &mtB);
	
	D3DXVECTOR3 vcCam	= D3DXVECTOR3(mtB._41, mtB._42, mtB._43);
	D3DXVECTOR3 vcZ		= D3DXVECTOR3(mtB._31, mtB._32, mtB._33);
	
	mtB._41 = 0;
	mtB._42 = 0;
	mtB._43 = 0;
	
	FLOAT fX;
	FLOAT fY;
	VtxDUV1	Vtx[4];
	D3DXVECTOR3	vcTmp;
	
	
	for(i=0; i<m_iN; ++i)
	{
		vcTmp = m_pBill[i].vcP-vcCam;
		m_pBill[i].fZ = D3DXVec3Dot(&vcZ, &vcTmp);
	}
	
	qsort (m_pBill, m_iN, sizeof(McBill), (int(*) (const void *, const void *)) this->SortFnc);
	
	for(i=0; i<m_iN; ++i)
	{
		INT	nIdx	= m_pBill[i].nT;
		
		fX = m_pTxTree[nIdx].Img.Width*.14f;
		fY = m_pTxTree[nIdx].Img.Height*.15f;
		
		Vtx[0] = VtxDUV1(-fX, fY, 0, 0, 0);
		Vtx[1] = VtxDUV1( fX, fY, 0, 1, 0);
		Vtx[2] = VtxDUV1(-fX,-fY, 0, 0, 1);
		Vtx[3] = VtxDUV1( fX,-fY, 0, 1, 1);
		
		D3DXVec3TransformCoord(&Vtx[0].p, &Vtx[0].p, &mtB);
		D3DXVec3TransformCoord(&Vtx[1].p, &Vtx[1].p, &mtB);
		D3DXVec3TransformCoord(&Vtx[2].p, &Vtx[2].p, &mtB);
		D3DXVec3TransformCoord(&Vtx[3].p, &Vtx[3].p, &mtB);
		
		Vtx[0].p += m_pBill[i].vcP;
		Vtx[1].p += m_pBill[i].vcP;
		Vtx[2].p += m_pBill[i].vcP;
		Vtx[3].p += m_pBill[i].vcP;
		
		Vtx[0].p.y += fY * 1.f;
		Vtx[1].p.y += fY * 1.f;
		Vtx[2].p.y += fY * 1.f;
		Vtx[3].p.y += fY * 1.f;
		
		m_pVtx[i*6+0] = Vtx[0];
		m_pVtx[i*6+1] = Vtx[1];
		m_pVtx[i*6+2] = Vtx[2];
		m_pVtx[i*6+3] = Vtx[3];
		m_pVtx[i*6+4] = Vtx[2];
		m_pVtx[i*6+5] = Vtx[1];
	}
	
	
	return 0;
}


void CMcTree::Render()
{
	INT	i=0;
	
	m_pDev->SetRenderState(D3DRS_LIGHTING, FALSE);

	m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
		
	
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	
	m_pDev->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
	
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE );
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE );
	
	m_pDev->SetFVF(VtxDUV1::FVF);
	
	
	for(i=0; i<m_iN; ++i)
	{
		m_pDev->SetTexture(0, m_pTxTree[m_pBill[i].nT].pTx);
		m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLELIST, 2, &m_pVtx[i*6+0], sizeof(VtxDUV1));
	}
	
//	m_pDev->SetTexture(0, m_pTxTree[0].pTx);
//	m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLELIST, 2*m_iN, m_pVtx, sizeof(VtxDUV1));
	
	m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
	
}




// ����Ʈ ����� ���ϴ� ���� DirectX SDK���� ������ �ȵǹǷ� ���� ����
void LcxMatrixViewport(D3DXMATRIX* pOut, const D3DVIEWPORT9* pV /*Viewport*/)
    {
    float   fW = 0;
    float   fH = 0;
    float   fD = 0;
    float   fY = 0;
    float   fX = 0;

    float   fM = FLOAT(pV->MinZ);

    fW = FLOAT(pV->Width)*.5f;
    fH = FLOAT(pV->Height)*.5f;
    fD = FLOAT(pV->MaxZ) - FLOAT(pV->MinZ);
    fX = FLOAT(pV->X) + fW;
    fY = FLOAT(pV->Y) + fH;

    *pOut = D3DXMATRIX( fW,  0.f,  0, 0,
                       0.f,  -fH,  0, 0,
                       0.f,  0.f, fD, 0,
                       fX,    fY, fM, 1);
}




void CMcTree::RenderIndex(ID3DXFont* pFont)
{
	D3DXVECTOR3 vcCamZ;			// Camera Z Axis
	D3DXVECTOR3 vcEye;			// Camera Position

	D3DXMATRIX	mtView;
	D3DXMATRIX	mtProj;
	D3DXMATRIX	mtViewI;

	// ����Ʈ ���
	D3DXMATRIX      mtVp;
	D3DVIEWPORT9    vp;

	m_pDev->GetTransform(D3DTS_VIEW, &mtView);
	m_pDev->GetTransform(D3DTS_PROJECTION, &mtProj);
	m_pDev->GetViewport(&vp);


	D3DXMatrixInverse(&mtViewI, NULL, &mtView);

	vcCamZ = D3DXVECTOR3( mtViewI._31, mtViewI._32, mtViewI._33);
	vcEye  = D3DXVECTOR3( mtViewI._41, mtViewI._42, mtViewI._43);

	// ����Ʈ ��� ����
	LcxMatrixViewport(&mtVp, &vp);

	// ��ȯ ��� = ���� ��� * ����� * ���� ��� * ����Ʈ ���
	D3DXMATRIX  mtTMpt  = mtView * mtProj * mtVp;




	for(INT i=0; i<m_iN; ++i)
	{
		D3DXVECTOR3 vcOut;
		D3DXVECTOR3 vcIn;
		FLOAT		fZ;

		vcIn = m_pVtx[i*6+0].p + m_pVtx[i*6+1].p;
		vcIn *=0.5f;

		fZ = D3DXVec3Dot(&vcCamZ, &(vcIn-vcEye));

		if(fZ<=0.f)
			continue;


		// ��� 1
		// ����� ���ؼ� ����ϰ� �Ǹ� �ѹ��� ��ȯ
		D3DXVec3TransformCoord(&vcOut, &vcIn, &mtTMpt);

		// ��� 2
		// ��, ����, ����Ʈ ��ȯ�� �ܰ������� ������ ���� �ִ�.
		// �Ź� ��� ������ �Ҹ�ǹǷ� ��� 1���� ���ϰ� ���.
		//	D3DXVECTOR3 vcT;
		//	D3DXVec3TransformCoord(&vcT, &vcIn, &mtView);	// ���� ��ȯ
		//	D3DXVec3TransformCoord(&vcT, &vcT, &mtProj);	// ���� ��ȯ
		//	D3DXVec3TransformCoord(&vcT, &vcIn, &mtVp);		// ����Ʈ ��ȯ
		//	vcOut = vcT;

		// ��� 3
		// D3DXVec3Project() �Լ��� ����ϸ� ��� 2�� ���������� �Ź�
		// ��� ������ ���ο��� �����Ѵ�.
		//	D3DXVec3Project(&vcOut, &vcIn, &vp, &mtProj, &mtView, NULL);

		RECT rc={ int(vcOut.x), int(vcOut.y), 0,0};


		TCHAR szMsg[128];
		sprintf(szMsg, "%d", i);

		DWORD dColor = D3DXCOLOR(1,1,0,1);

		rc.right = rc.left + 400;
		rc.bottom= rc.top + 40;

		pFont->DrawText(NULL, szMsg, -1, &rc, 0, dColor );
	}
}




int CMcTree::GetObjNum()
{
	return m_iN;
}


D3DXVECTOR3	CMcTree::GetObjPos(int i)
{
	return m_pBill[i].vcP;
}


void CMcTree::SetObjPos(int i, D3DXVECTOR3 vcP)
{
	m_pBill[i].vcP = vcP;
}
