// Interface for the CMcField class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MCFIELD_H_
#define _MCFIELD_H_

class CMcField
{
public:
	struct Vtx
	{
		D3DXVECTOR3	p;
		
		Vtx()		{}
		Vtx(FLOAT X,FLOAT Y,FLOAT Z):p(X,Y,Z){}
		enum	{FVF = (D3DFVF_XYZ),};
	};


	struct VtxIdx
	{
		union	{	struct	{	WORD a;	WORD b;	WORD c;	};	WORD m[3];	};

		VtxIdx()							{	a = 0;	  b = 1;		 c = 2;	}
		VtxIdx(WORD A, WORD B, WORD C)		{	a = A;    b = B;		 c = C;	}
		VtxIdx(WORD* R)						{	a = R[0]; b = R[1];	 c = R[2];	}
		operator WORD* ()					{		return (WORD *) &a;			}
		operator CONST WORD* () const		{		return (CONST WORD *) &a;	}
	};

protected:
	LPDIRECT3DDEVICE9 m_pDev;
	Vtx*		m_pVtx;
	VtxIdx*		m_pFce;

	int			m_TileN;
	FLOAT		m_TileW;
	int			m_nVtx;
	int			m_nFce;
	float		m_fHscl;

public:
	CMcField();
	virtual ~CMcField();

	INT		Create(LPDIRECT3DDEVICE9 pDev, char* sRaw);
	void	Destroy();

	INT		FrameMove();
	void	Render();
};

#endif