// Implementation of the CMcField class.
//
////////////////////////////////////////////////////////////////////////////////


#pragma warning( disable : 4996)

#include <windows.h>
#include <stdio.h>
#include <d3d9.h>
#include <d3dx9.h>

#include "dxutil.h"

#include "McField.h"


CMcField::CMcField()
{
	m_pVxOrg	= NULL;
	m_pFce	= NULL;

	m_TileN	= 0;
	m_TileW	= 0;

	m_nVtx	= 0;
	m_nFce	= 0;

	m_pVxD	=NULL;
}


CMcField::~CMcField()
{
	Destroy();
}


INT CMcField::Create(LPDIRECT3DDEVICE9 pDev)
{
	m_pDev	= pDev;

	int x;
	int z;
	int n;
	INT	nVtxT;		// �࿡ ���� ���ؽ� ��

	int i=0;

	m_TileN = 128;
	m_TileW = 2.f;

	nVtxT	= m_TileN+1;
	m_nVtx	= nVtxT * nVtxT;
	m_nFce	= 2* m_TileN * m_TileN;


	m_pVxOrg = new Vtx[m_nVtx];
	m_pFce = new VtxIdx[m_nFce];


	// 1. ������ �ε��� ����
	
//	1-----3
//	.\    |
//	.  \  |
//	.    \|
//	0-----2
	n=0;

	for(z=0; z<m_TileN; ++z)
	{
		for(x=0;x<m_TileN; ++x)
		{
			int _0 = nVtxT*(z+0) +x;
			int _1 = nVtxT*(z+1) +x;
			int _2 = nVtxT*(z+0) +x +1;
			int _3 = nVtxT*(z+1) +x +1;


			m_pFce[n] = VtxIdx(_0, _1, _2);
			++n;
			m_pFce[n] = VtxIdx(_3, _2, _1);
			++n;
		}
	}


	for(z=0; z<=m_TileN; ++z)
	{
		for(x=0;x<=m_TileN; ++x)
		{
			n = z * nVtxT + x;

			m_pVxOrg[n].p = D3DXVECTOR3( FLOAT(x), 0.F, FLOAT(z));
			m_pVxOrg[n].p *= m_TileW;
		}
	}

	

	//2. ���� ����(Test)
	for(z=0; z<=m_TileN; ++z)
	{
		for(x=0;x<=m_TileN; ++x)
		{
			FLOAT h;
			FLOAT fTx = x-nVtxT/2.f;		// ������ �߽��� X
			FLOAT fTz = z-nVtxT/2.f;		// ������ �߽��� Z
			fTx *= fTx;
			fTz *= fTz;
			fTz += fTx;
			fTz *=-0.0014f;
			h = expf( fTz) *50.f;
//			h = 40*(cosf(x/ FLOAT(m_TileN*.1F) )*cosf(z/ FLOAT(m_TileN*.1F) )+1.0f);

			n = z * nVtxT + x;

			m_pVxOrg[n].p.y = h;

		}
	}



	m_pVxD	= new Vtx*[100];

	for(i=0;i<100; ++i)
	{
		m_pVxD[i] = new Vtx[m_nVtx];
	}


	for(i=0;i<100; ++i)
	{
		memcpy( m_pVxD[i], m_pVxOrg, sizeof(Vtx) *m_nVtx);
	}


	for(i=0;i<100; ++i)
	{
		Vtx*	pVxD = m_pVxD[i];

		D3DXVECTOR3	vcStart( 0, 0, i*m_TileN * m_TileW);


		for(z=0; z<=m_TileN; ++z)
		{
			for(x=0;x<=m_TileN; ++x)
			{
				n = z * nVtxT + x;

				pVxD[n].p += vcStart;
			}
		}
	}


	return 0;
}


void CMcField::Destroy()
{
	SAFE_DELETE_ARRAY(	m_pVxOrg	);
	SAFE_DELETE_ARRAY(	m_pFce	);

	if(m_pVxD)
	{
		for(int i=0;i<100; ++i)
		{
			delete [] m_pVxD[i];
		}

		delete [] m_pVxD;
		m_pVxD = NULL;
	}
}


INT	CMcField::FrameMove()
{
	
	return 0;
}

void CMcField::Render()
{
	m_pDev->SetRenderState( D3DRS_FILLMODE, D3DFILL_WIREFRAME);
	m_pDev->SetRenderState( D3DRS_LIGHTING,  FALSE);
	m_pDev->SetRenderState( D3DRS_CULLMODE,  D3DCULL_NONE);
	m_pDev->SetRenderState( D3DRS_ALPHABLENDENABLE,  FALSE);
	m_pDev->SetRenderState( D3DRS_ALPHATESTENABLE,  FALSE);

	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_NONE);

	m_pDev->SetTexture(0, NULL);
	m_pDev->SetFVF(Vtx::FVF);

	
	D3DXMATRIX	mtViw;
	D3DXMATRIX	mtViwI;
	m_pDev->GetTransform(D3DTS_VIEW, &mtViw);
	D3DXMatrixInverse(&mtViwI, NULL, &mtViw);

	D3DXVECTOR3	vcCam( mtViwI._41, mtViwI._42, mtViwI._43);

	int nBlock = INT(vcCam.z/(m_TileN * m_TileW));


	for(int i=nBlock-1;i<=(nBlock+6); ++i)
	{
		if(i<0)
			continue;
		
		if(i>=100)
			break;

		Vtx*	pVxD = m_pVxD[i];

		m_pDev->DrawIndexedPrimitiveUP(
		D3DPT_TRIANGLELIST
		, 0
		, m_nVtx
		, m_nFce
		, m_pFce
		, D3DFMT_INDEX16
		, pVxD, sizeof(Vtx));
	}

	



	m_pDev->SetTexture(0, NULL);
	m_pDev->SetTexture(1, NULL);

	m_pDev->SetRenderState( D3DRS_FILLMODE, D3DFILL_SOLID);
	m_pDev->SetRenderState( D3DRS_CULLMODE,  D3DCULL_CCW);
}




INT CMcField::GetHeight(D3DXVECTOR3* pOut, const D3DXVECTOR3* pIn)
{
	D3DXVECTOR3	vcLcl = *pIn;
	D3DXVECTOR3	vcWld = *pIn;

	//�����ε���
	int nBlock = INT(vcLcl.z/(m_TileN * m_TileW));

	
	if(nBlock<0 || nBlock>=100)
		return -1;

	// �ش� ������ ������
	Vtx*	pVxD = m_pVxD[nBlock];

	// �ش� ������ ������
	D3DXVECTOR3	vcStart( 0, 0, nBlock*m_TileN * m_TileW);

	vcLcl	-= vcStart;


	int nX = int( vcLcl.x/ (m_TileW+0.0001f) );
	int nZ = int( vcLcl.z/ (m_TileW+0.0001f) );

	// ����
	if(nX<0|| nX>=m_TileN ||
		nZ<0|| nZ>=m_TileN)
		return -1;

	//	1------3
	//	.��    |
	//	.  ��  |
	//	.    ��|
	//	0------2

	int _0 = nX +0 + (m_TileN+1)*(nZ+0);
	int _1 = nX +0 + (m_TileN+1)*(nZ+1);
	int _2 = nX +1 + (m_TileN+1)*(nZ+0);
	int _3 = nX +1 + (m_TileN+1)*(nZ+1);


	FLOAT	dX = vcLcl.x - nX * m_TileW;
	FLOAT	dZ = vcLcl.z - nZ * m_TileW;

	D3DXVECTOR3 vcX;
	D3DXVECTOR3 vcZ;
	D3DXVECTOR3 vcOut;

	if( (dX+dZ) <=m_TileW)	// �Ʒ� �� �ﰢ��
	{
		vcX = pVxD[_2].p - pVxD[_0].p;
		vcZ = pVxD[_1].p - pVxD[_0].p;

		vcOut = vcX * dX/m_TileW + vcZ * dZ/m_TileW;
		vcOut +=pVxD[_0].p;
	}
	else					// �� �� �ﰢ��
	{
		dX = pVxD[_3].p.x - vcWld.x;
		dZ = pVxD[_3].p.z - vcWld.z;
		
		vcX = pVxD[_1].p - pVxD[_3].p;
		vcZ = pVxD[_2].p - pVxD[_3].p;

		vcOut = vcX * dX/m_TileW + vcZ * dZ/m_TileW;
		vcOut +=pVxD[_3].p;
	}

	*pOut = vcOut;

	return 0;
}

