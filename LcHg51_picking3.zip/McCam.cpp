// Implementation of the CMcCam class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMcCam::CMcCam()
{

}

CMcCam::~CMcCam()
{

}


INT CMcCam::Create(LPDIRECT3DDEVICE9 pDev)
{
	m_pDev		= pDev;

	m_fYaw		= 0.f;
	m_fPitch	= 0.f;
	m_vcEye		= D3DXVECTOR3(520, 770, 230);
	m_vcLook	= D3DXVECTOR3(510, 500, 420);
	m_vcUp		= D3DXVECTOR3(0,1,0);


	// get the screen width and height
	D3DDEVICE_CREATION_PARAMETERS pp={0};
	RECT rc={0};
	m_pDev->GetCreationParameters(&pp);
	GetClientRect(pp.hFocusWindow, &rc);


	m_fScnW	= (FLOAT)(rc.right - rc.left);
	m_fScnH	= (FLOAT)(rc.bottom- rc.top);
	m_fFv	= D3DX_PI/4.f;
	m_fAs	= m_fScnW/m_fScnH;
	m_fNr	= 1.f;
	m_fFr	= 5000.f;

	D3DXMatrixPerspectiveFovLH(&m_mtPrj,m_fFv, m_fAs, m_fNr, m_fFr);
	D3DXMatrixLookAtLH(&m_mtViw, &m_vcEye, &m_vcLook, &m_vcUp);

	return 1;
}


INT CMcCam::FrameMove()
{
	// Wheel mouse...
	VEC3 vcD = g_pApp->m_pInput->GetMouseDelta();

	if(vcD.z !=0.f)
	{
		MoveForward(-vcD.z* .1f, 1.f);
		D3DXMatrixLookAtLH(&m_mtViw, &m_vcEye, &m_vcLook, &m_vcUp);
	}

	if(g_pApp->m_pInput->KeyState(DIK_W))					// W
	{
		MoveForward( 1.f, 1.f);
		D3DXMatrixLookAtLH(&m_mtViw, &m_vcEye, &m_vcLook, &m_vcUp);
	}

	if(g_pApp->m_pInput->KeyState(DIK_S))					// S
	{
		MoveForward(-1.f, 1.f);
		D3DXMatrixLookAtLH(&m_mtViw, &m_vcEye, &m_vcLook, &m_vcUp);
	}


	if(g_pApp->m_pInput->KeyState(DIK_A))					// A
	{
		MoveSideward(-1.f);
		D3DXMatrixLookAtLH(&m_mtViw, &m_vcEye, &m_vcLook, &m_vcUp);
	}

	if(g_pApp->m_pInput->KeyState(DIK_D))					// D
	{
		MoveSideward(1.f);
		D3DXMatrixLookAtLH(&m_mtViw, &m_vcEye, &m_vcLook, &m_vcUp);
	}


	if(g_pApp->m_pInput->GetMouseSt(1))
	{
		VEC3	vcDelta = g_pApp->m_pInput->GetMouseDelta();
		m_fYaw   = D3DXToRadian(vcDelta.x * 0.1f);
		m_fPitch   = D3DXToRadian(vcDelta.y * 0.1f);

		D3DXMATRIX rot;
		VEC3 vcZ = m_vcLook-m_vcEye;
		VEC3 vcX;
		D3DXMatrixRotationY(&rot, m_fYaw);
		D3DXVec3TransformCoord(&vcZ, &vcZ, &rot);
		D3DXVec3TransformCoord(&m_vcUp, &m_vcUp, &rot);

		m_vcLook = vcZ + m_vcEye;
		D3DXMatrixLookAtLH(&m_mtViw, &m_vcEye, &m_vcLook, &m_vcUp);


		vcZ = m_vcLook - m_vcEye;
		vcX =VEC3(m_mtViw._11, m_mtViw._21, m_mtViw._31);

		D3DXMatrixRotationAxis(&rot, & vcX, m_fPitch);
		D3DXVec3TransformCoord(&vcZ, &vcZ, &rot);
		D3DXVec3TransformCoord(&m_vcUp, &m_vcUp, &rot);

		m_vcLook = vcZ + m_vcEye;
		D3DXMatrixLookAtLH(&m_mtViw, &m_vcEye, &m_vcLook, &m_vcUp);
	}



	D3DXMatrixInverse(&m_mtViwI, 0, &m_mtViw);

	m_mtBill = m_mtViwI;
	m_mtBill._41 = m_mtBill._42 = m_mtBill._43 = 0;								// Bill board Matrix

//	m_vcEye		= VEC3( m_mtViwI._41, m_mtViwI._42, m_mtViwI._43);				// Camera Position ReSetting
	m_mtVwPj	= m_mtViw * m_mtPrj;

	VEC3 vcLf = -VEC3(m_mtVwPj._14 + m_mtVwPj._11, m_mtVwPj._24 + m_mtVwPj._21, m_mtVwPj._34 + m_mtVwPj._31);		// Left
	VEC3 vcRg = -VEC3(m_mtVwPj._14 - m_mtVwPj._11, m_mtVwPj._24 - m_mtVwPj._21, m_mtVwPj._34 - m_mtVwPj._31);		// Right
	VEC3 vcTp = -VEC3(m_mtVwPj._14 - m_mtVwPj._12, m_mtVwPj._24 - m_mtVwPj._22, m_mtVwPj._34 - m_mtVwPj._32);		// Top
	VEC3 vcBt = -VEC3(m_mtVwPj._14 + m_mtVwPj._12, m_mtVwPj._24 + m_mtVwPj._22, m_mtVwPj._34 + m_mtVwPj._32);		// Bottom
	VEC3 vcNr = -VEC3(m_mtViwI._31, m_mtViwI._32, m_mtViwI._33);				// Near
	VEC3 vcFr = -vcNr;															// Far
	VEC3 vcZn = m_vcEye + vcNr * m_fNr;
	VEC3 vcZf = m_vcEye + vcNr * m_fFr;

	D3DXPlaneFromPointNormal((D3DXPLANE*)&m_Frsm[0], &vcZn, &vcNr);				// Near Plane
	D3DXPlaneFromPointNormal((D3DXPLANE*)&m_Frsm[1], &vcZf, &vcFr);				// Far Plane
	D3DXPlaneFromPointNormal((D3DXPLANE*)&m_Frsm[2], &m_vcEye, &vcLf);			// Left Plane
	D3DXPlaneFromPointNormal((D3DXPLANE*)&m_Frsm[3], &m_vcEye, &vcRg);			// Right Plane
	D3DXPlaneFromPointNormal((D3DXPLANE*)&m_Frsm[4], &m_vcEye, &vcTp);			// Top Plane
	D3DXPlaneFromPointNormal((D3DXPLANE*)&m_Frsm[5], &m_vcEye, &vcBt);			// Bottom Plane


	m_pDev->SetTransform(D3DTS_VIEW, &m_mtViw);
	m_pDev->SetTransform(D3DTS_PROJECTION, &m_mtPrj);

	return 1;
}

void CMcCam::MoveSideward(FLOAT fSpeed)
{
	VEC3 tmp(m_mtViw._11, 0, m_mtViw._31);
	D3DXVec3Normalize(&tmp,&tmp);

	m_vcEye  += tmp * fSpeed;
	m_vcLook += tmp * fSpeed;
}


void CMcCam::MoveForward(FLOAT fSpeed, FLOAT fY)
{
	VEC3 tmp(m_mtViw._13, m_mtViw._23*fY, m_mtViw._33);
	D3DXVec3Normalize(&tmp,&tmp);

	m_vcEye  += tmp * fSpeed;
	m_vcLook += tmp * fSpeed;
}


INT CMcCam::GetPickLayDirection(VEC3* pOut, FLOAT mouseX, FLOAT mouseY)
{
	FLOAT w     = m_mtPrj._11;
	FLOAT h     = m_mtPrj._22;

	FLOAT viw_x =  ( 2.f * mouseX / m_fScnW - 1 ) / w;
	FLOAT viw_y = -( 2.f * mouseY / m_fScnH - 1 ) / h;

	/*
	VEC3	vcScn(viw_x, viw_y, 1.0F);

	// Transform the screen space pick ray into 3D space
	// Ray Direction
	pOut->x  = D3DXVec3Dot(&vcScn, &VEC3(m_mtViwI._11, m_mtViwI._21, m_mtViwI._31));
	pOut->y  = D3DXVec3Dot(&vcScn, &VEC3(m_mtViwI._12, m_mtViwI._22, m_mtViwI._32));
	pOut->z  = D3DXVec3Dot(&vcScn, &VEC3(m_mtViwI._13, m_mtViwI._23, m_mtViwI._33));
	*/


	D3DXVECTOR3 vcCamX = D3DXVECTOR3(m_mtViw._11, m_mtViw._21, m_mtViw._31);
	D3DXVECTOR3 vcCamY = D3DXVECTOR3(m_mtViw._12, m_mtViw._22, m_mtViw._32);
	D3DXVECTOR3 vcCamZ = D3DXVECTOR3(m_mtViw._13, m_mtViw._23, m_mtViw._33);

	*pOut = viw_x * vcCamX + viw_y * vcCamY + vcCamZ;

	return 0;
}
