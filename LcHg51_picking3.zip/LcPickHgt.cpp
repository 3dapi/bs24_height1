// Implementation of the CLcPickHgt class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CLcPickHgt::CLcPickHgt()
{
	m_pVc = NULL;
	m_pVi = NULL;

	m_pVtx[0].d = 0xFFFF00FF;
	m_pVtx[1].d = 0xFFFF00FF;
	m_pVtx[2].d = 0xFFFF00FF;
}

CLcPickHgt::~CLcPickHgt()
{
	Destroy();
}


D3DXVECTOR3	m_vcShf = D3DXVECTOR3(-200, -600, 400);


INT CLcPickHgt::Create(LPDIRECT3DDEVICE9 pDev)
{
	m_pDev = pDev;

	int		x, z;
	
	m_fW	= 42;
	m_iNx	= 32+1;
	m_iNz	= 32+1;
	m_iNv	= m_iNx * m_iNz * 3 * 2;

	m_pLine[0].p = D3DXVECTOR3(  600, 0, -20);
	m_pLine[1].p = D3DXVECTOR3(  -10, 0,  20);

	m_pLine[0].p = D3DXVECTOR3(  -10, 0, -10);
	m_pLine[1].p = D3DXVECTOR3(  300, 0, 280);



	m_pVc = new VtxD[m_iNv];

	// Fill Vertex buffer
	for(z=0; z<m_iNz; ++z)
	{
		for(x=0; x<m_iNx; ++x)
		{
			int idx = z * m_iNx + x;
			FLOAT fH = (x-m_iNx/2)*(x-m_iNx/2) + (z-m_iNx/2) * (z-m_iNx/2);
			
			fH = (x-m_iNx/2)*(x-m_iNx/2) - (z-m_iNx/2) * (z-m_iNx/2);
			fH *=2.5f;

			m_pVc[idx] = VtxD( x * m_fW
							, fH
							, z * m_fW
							, 0xFF0088DD);

			m_pVc[idx].p +=m_vcShf;
		}
	}



	m_iNfc = (m_iNx-1) * (m_iNz-1) * 2;				// �ﰢ���� ��

	m_pVi = new VtxIdx[m_iNfc];

	// Fill Index buffer
	INT iN = m_iNx-1;
	
	
	INT i=0;
	
	WORD index;
	WORD f[9];
	
	for(z=0; z< iN/2;++z)														// Index�� ä���.
	{
		for(x=0;x<iN/2;++x)
		{
			index = 2*m_iNx*z + m_iNx+1 + 2*x;
			
			f[6] = index +m_iNx-1;	f[5] = index + m_iNx;	f[4] = index +m_iNx+1;
			f[7] = index       -1;	f[8] = index	    ;	f[3] = index       +1;
			f[0] = index -m_iNx-1;	f[1] = index - m_iNx;	f[2] = index -m_iNx+1;
			
			
			i = z * iN/2 + x;
			i *=8;
			
			for(int m=0; m<8; ++m)
				m_pVi[i+m] = VtxIdx( f[8], f[(m+1)%8], f[(m+0)%8]);
		}
	}

	return 1;
}


void CLcPickHgt::Destroy()
{
	SAFE_DELETE_ARRAY(	m_pVc	);
	SAFE_DELETE_ARRAY(	m_pVi	);
}



INT	CLcPickHgt::FrameMove()
{
	D3DXVECTOR3 vcCamPos;
	D3DXVECTOR3 vcRayDir;


	vcCamPos = GCAM->GetCamPos();


	FLOAT fMouseX = (FLOAT)GINPUT->GetMousePos().x;
	FLOAT fMouseY = (FLOAT)GINPUT->GetMousePos().y;
	GCAM->GetPickLayDirection(&vcRayDir, fMouseX, fMouseY);


	m_pLine[0].p = vcCamPos;
	m_pLine[1].p = vcCamPos + vcRayDir*100000;
	m_pLine[0].p.y =0;
	m_pLine[1].p.y =0;
	
	LcPck	pPck;

	m_pVtx[0].p = D3DXVECTOR3(0,0,0);
	m_pVtx[1].p = D3DXVECTOR3(0,0,0);
	m_pVtx[2].p = D3DXVECTOR3(0,0,0);

	m_vRc.clear();

	if(SUCCEEDED(Picking(vcCamPos, vcRayDir, &pPck, &m_vRc, m_pVc, m_vcShf, m_iNx, m_fW)))
	{
		m_pVtx[0].p = pPck.vcT3[0];
		m_pVtx[1].p = pPck.vcT3[1];
		m_pVtx[2].p = pPck.vcT3[2];
	}

	return 1;
}


INT	Picking(	D3DXVECTOR3		vcCamPos
			,	D3DXVECTOR3		vcRayDir
			,	LcPck*		pPck
			,	lsLcRect*	pvOutRect
			,	VtxD*		pVtices
			,	D3DXVECTOR3		vcShift
			,	INT			iNx
			,	FLOAT		fW
						)
{
	if(!pVtices)
		return -1;

	lsLcRect vRect;
	lsPck	vPck;
	D3DXVECTOR3	pLine[2];

	pLine[0] = vcCamPos;
	pLine[1] = vcCamPos + vcRayDir*1000000;

	pLine[0].y =0;
	pLine[1].y =0;

	

	FLOAT	fA;
	FLOAT	fB;
	D3DXVECTOR3	vcD = pLine[1]- pLine[0];

	if(0.f == vcD.x)
		fA = FLT_MAX;
	
	else
		fA= vcD.z/vcD.x;

	fA = fA;
	fB = (pLine[0].z - vcShift.z) - fA * (pLine[0].x-vcShift.x);

	for(int i=0; i<iNx; ++i)
	{
		FLOAT	x;
		FLOAT	z;

		z = fA* i + fB/fW;
		z = floorf(z);
		
		if( z>=0 && z<(iNx-1) && i<(iNx-1))
		{
			LcRect	rc;

			INT nTx = INT(z) * iNx + i;

			if( nTx%2)
			{
				rc.pVtx[0].p = pVtices[(INT(z)+0)* iNx + i ].p;
				rc.pVtx[1].p = pVtices[(INT(z)+1)* iNx + i ].p;
				rc.pVtx[2].p = pVtices[(INT(z)+0)* iNx + i + 1].p;
				rc.pVtx[3].p = pVtices[(INT(z)+1)* iNx + i + 1].p;
			}

			else
			{
				rc.pVtx[2].p = pVtices[(INT(z)+0)* iNx + i ].p;
				rc.pVtx[0].p = pVtices[(INT(z)+1)* iNx + i ].p;
				rc.pVtx[3].p = pVtices[(INT(z)+0)* iNx + i + 1].p;
				rc.pVtx[1].p = pVtices[(INT(z)+1)* iNx + i + 1].p;
			}
			
			if( fabsf(rc.pVtx[0].p.x - rc.pVtx[3].p.x) <=fW &&
				fabsf(rc.pVtx[0].p.z - rc.pVtx[3].p.z) <=fW)
				vRect.push_back(rc);
		}


		z = i * fW;
		x = (z - fB)/(fA*fW);
		x = floorf(x);

		if( x>=0 && x<(iNx-1))
		{
			if(fA>=0)
			{
				LcRect	rc;

				INT nTx = INT(i) * iNx + INT(x);

				if(nTx%2)
				{
					rc.pVtx[0].p = pVtices[(INT(i)+0)* iNx + INT(x) ].p;
					rc.pVtx[1].p = pVtices[(INT(i)+1)* iNx + INT(x) ].p;
					rc.pVtx[2].p = pVtices[(INT(i)+0)* iNx + INT(x) + 1].p;
					rc.pVtx[3].p = pVtices[(INT(i)+1)* iNx + INT(x) + 1].p;
				}

				else
				{
					rc.pVtx[2].p = pVtices[(INT(i)+0)* iNx + INT(x) ].p;
					rc.pVtx[0].p = pVtices[(INT(i)+1)* iNx + INT(x) ].p;
					rc.pVtx[3].p = pVtices[(INT(i)+0)* iNx + INT(x) + 1].p;
					rc.pVtx[1].p = pVtices[(INT(i)+1)* iNx + INT(x) + 1].p;
				}				

				if( fabsf(rc.pVtx[0].p.x - rc.pVtx[3].p.x) <=fW &&
					fabsf(rc.pVtx[0].p.z - rc.pVtx[3].p.z) <=fW)
					vRect.push_back(rc);
			}

			else if(z>0)
			{
				z = (i-1);

				LcRect	rc;

				INT nTx = INT(z) * iNx + INT(x);

				if( nTx%2)
				{
					rc.pVtx[0].p = pVtices[(INT(z)+0)* iNx + INT(x) ].p;
					rc.pVtx[1].p = pVtices[(INT(z)+1)* iNx + INT(x) ].p;
					rc.pVtx[2].p = pVtices[(INT(z)+0)* iNx + INT(x) + 1].p;
					rc.pVtx[3].p = pVtices[(INT(z)+1)* iNx + INT(x) + 1].p;
				}

				else
				{
					rc.pVtx[2].p = pVtices[(INT(z)+0)* iNx + INT(x) ].p;
					rc.pVtx[0].p = pVtices[(INT(z)+1)* iNx + INT(x) ].p;
					rc.pVtx[3].p = pVtices[(INT(z)+0)* iNx + INT(x) + 1].p;
					rc.pVtx[1].p = pVtices[(INT(z)+1)* iNx + INT(x) + 1].p;
				}


				if( fabsf(rc.pVtx[0].p.x - rc.pVtx[3].p.x) <=fW &&
					fabsf(rc.pVtx[0].p.z - rc.pVtx[3].p.z) <=fW)
					vRect.push_back(rc);
			}
		}
	}


	if(!vRect.empty())
	{
		vPck.clear();

		INT iSize = vRect.size();

		for(int i=0; i<iSize; ++i)
		{
			D3DXVECTOR3	V0, V1, V2;
			FLOAT	U, V, D;
			
			V0 = vRect[i].pVtx[0].p;
			V1 = vRect[i].pVtx[1].p;
			V2 = vRect[i].pVtx[2].p;

			if(	D3DXIntersectTri( &V0, &V1, &V2, &vcCamPos, &vcRayDir, &U, &V, &D))
			{
				LcPck	Pck;

				// Pick Position
				Pck.vcP = V0 + U * (V1-V0) + V * (V2-V0);

				Pck.vcT3[0] = V0;
				Pck.vcT3[1] = V1;
				Pck.vcT3[2] = V2;
				Pck.fR	= D;

				vPck.push_back( Pck );
			}

			V0 = vRect[i].pVtx[3].p;
			V1 = vRect[i].pVtx[2].p;
			V2 = vRect[i].pVtx[1].p;

			if(	D3DXIntersectTri( &V0, &V1, &V2, &vcCamPos, &vcRayDir, &U, &V, &D))
			{
				LcPck	Pck;

				// Pick Position
				Pck.vcP = V0 + U * (V1-V0) + V * (V2-V0);

				Pck.vcT3[0] = V0;
				Pck.vcT3[1] = V1;
				Pck.vcT3[2] = V2;
				Pck.fR	= D;

				vPck.push_back( Pck );
			}
		}


		if(pvOutRect)
		{
			for(int i=0; i<iSize; ++i)
			{
				pvOutRect->push_back(vRect[i]);
			}
		}

		if(!vPck.empty())
		{
			sort(vPck.begin(), vPck.end(), TsrtL<LcPck >());


			if(pPck)
			{
				pPck->vcP		= vPck[0].vcP;
				pPck->fR		= vPck[0].fR;
				pPck->vcT3[0]	= vPck[0].vcT3[0];
				pPck->vcT3[1]	= vPck[0].vcT3[1];
				pPck->vcT3[2]	= vPck[0].vcT3[2];
			}

			return 1;
		}
	}
	

	return -1;
}

void CLcPickHgt::Render()
{
	m_pDev->SetRenderState( D3DRS_CULLMODE, D3DCULL_NONE);
	m_pDev->SetRenderState( D3DRS_FILLMODE, D3DFILL_WIREFRAME);
	m_pDev->SetRenderState( D3DRS_LIGHTING,  FALSE);
	m_pDev->SetRenderState( D3DRS_ALPHABLENDENABLE,  FALSE);
	m_pDev->SetRenderState( D3DRS_ALPHATESTENABLE,  FALSE);
	m_pDev->SetRenderState( D3DRS_ZENABLE, FALSE);
	
	m_pDev->SetTexture(0, 0);
	m_pDev->SetFVF(VtxD::FVF);
	m_pDev->DrawPrimitiveUP(D3DPT_LINELIST, 1, m_pLine, sizeof(VtxD));

	m_pDev->SetFVF(VtxD::FVF);
	m_pDev->DrawIndexedPrimitiveUP(D3DPT_TRIANGLELIST, 0, m_iNv, m_iNfc, m_pVi, D3DFMT_INDEX16, m_pVc, sizeof(VtxD));


	VtxD	pVtx[4];
	int iSize = m_vRc.size();

	for(int i=0; i<iSize; ++i)
	{
		pVtx[0] = m_vRc[i].pVtx[0];
		pVtx[1] = m_vRc[i].pVtx[1];
		pVtx[2] = m_vRc[i].pVtx[2];
		pVtx[3] = m_vRc[i].pVtx[3];		
		
		m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, m_vRc[i].pVtx, sizeof(VtxD));
	}

	
	if(m_pVtx[0].p != m_pVtx[1].p)
	{
		m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 1, m_pVtx, sizeof(VtxD));
	}

	m_pDev->SetRenderState( D3DRS_ZENABLE, TRUE);
	m_pDev->SetRenderState( D3DRS_FILLMODE, D3DFILL_SOLID);
	m_pDev->SetRenderState( D3DRS_CULLMODE, D3DCULL_CCW);
}